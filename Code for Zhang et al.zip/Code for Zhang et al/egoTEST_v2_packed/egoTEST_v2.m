function egotest(varargin)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% ################################################################# %% DESCRIPTION
%FUNCTION  short desc.


% HISTORY:
% version 1.0.0, Release 00/00/00 Initial release
% Ningyu changed the size of distance bin according to envrionment type 
% A huge bug in calculating MRL  - 12/04/2020 Ningyu fixed 
%
% Author: Roddy Grieves
% UCL, 26 Bedford Way
% eMail: r.grieves@ucl.ac.uk
% Copyright 2019 Roddy Grieves

% Ningyu updated the threshold of distance edge bin size 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% ################################################################# %% INPUT ARGUMENTS CHECK
%% Prepare default settings
    def_tetrodes            = 1:16;        
    def_clusters            = 0;     
    def_cname               = 'kwiktint';   
    
%% Parse inputs
    p = inputParser;
    addOptional(p,'tetrodes',def_tetrodes,@(x) ~isempty(x) && ~all(isnan(x(:))) && isnumeric(x));  
    addOptional(p,'clusters',def_clusters,@(x) ~isempty(x) && ~all(isnan(x(:))) && isnumeric(x)); 
    addOptional(p,'cname',def_cname,@(x) ~isempty(x) && ~all(isnan(x(:))) && ischar(x));     
    parse(p,varargin{:});

%% Retrieve parameters 
    config = p.Results;        
    maintain_sdata = 0; % set to 1 to save/load mtint in the base workspace, this saves time when running the function mutliple times (for instance in debugging) but should otherwise be set to 0
    
% overrides
    close all; fclose('all'); tic;
    override_pconfig = 0;
    override_shuffles = 0; % set to 1 to recalculate shuffles even if they have already been performed before

% figure settings
    fig_vis = 'off'; % set to 'on' to show figures after they are generated, set to 'off' for them to be invisible
    fsiz = 8;
    flnw = 1;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% ################################################################# %% INITIAL SETTINGS / INPUTS
%% retrieve sdata structure
% klustest makes and saves a table named 'sdata' and a structure named pdata, these contain all the data for all the clusters
% analysed and prepared in a nice way. So it is a sort of beautified mtint. Although it does also contain things like 
% ratemaps etc. We want to load this structure so we can use the contents in our function. The downside of this convenience
% is that klustest has to have been run on a session before this function will work - the upside is that it greatly increases
% the speed of this function.
    disp(sprintf('\t...retrieving sdata and pdata'));
    if any(strcmp(evalin('base','who'),'sdata')) && maintain_sdata
        disp(sprintf('\t...using sdata held in memory'));
        sdata = evalin('base','sdata'); 
        pdata = evalin('base','pdata');        
    else
        disp(sprintf('\t...loading saved sdata and pdata'));
        load([pwd '\klustest\' config.cname '\' config.cname '_sdata.mat'],'sdata','-mat'); 
        load([pwd '\klustest\' config.cname '\' config.cname '_pdata.mat'],'pdata','-mat'); % load sdata and pdata    
        if maintain_sdata
            assignin('base','sdata',sdata); 
            assignin('base','pdata',pdata); % leave sdata and pdata in base workspace            
        end
    end
    
    % Specify partition configuration settings
    part_names = table2cell(pdata.part_config(:,2))'; % the names you want the outputs to be saved as, these cannot start with a number: i.e. 'session1'
    nparts = length(part_names);
    % method of partition, corresponding to each of the names above: 1 = combine everything, 2 = take a recording session, 3 = use digital inputs
    part_methods = pdata.part_config{:,3}'; % i.e. if part_methods=[2 2 2 1], we will have 4 parts, the first 3 correspond to some combination of recording sessions (there can be multiple ones) and the last one will include all data
    % cell array of vectors indicating which intervals to include in each partition: if method = 1 this does nothing, if method = 2 this should specify which recording sessions to include, if method = 3 this should specify which digital input pairs to include (inf = use all)
    part_intervals = table2cell(pdata.part_config(:,4))'; % i.e. if part_methods=[2 2 2], then if part_intervals={1 2 3}, rec 1 will go in part 1, rec 2 in part 2 and rec 3 in part 3    OR     if part_methods=[2 2 2 2 2], then if part_intervals={1 [2 4 5] 3}, rec 1 will go in part 1, rec 2,4 and 5 in part 2 and rec 3 in part 3
    conset = pdata.conset;
    envset = pdata.envset;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% ################################################################# %% partitioning settings
% in Klustest we also make a part_config structure which tells the function how to partition or divide up the data
% we will use the same structure here, although it has to of been made with the context box in mind. i.e most people
% will not have fields like 'etype' (environment type) in their part_config because that isn't something klustest uses
% the upside to this method is that all the info we need is in one place - part_config inside sdata, the downside
% is that the part_config has to be made properly to begin with. However, it can be overridden here. For instance you
% can define a new part_config at the top of the function and then commen out the "part_config = sdata.part_config;" line
% here. The effect would be that the function will use the new part_config defined here. But the number of parts in this new one
% will have to match the old one used by klustest
    disp(sprintf('\t...retrieving partitions...'))
    part_config = pdata.part_config;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% ################################################################# %% Retrieve and analyse data
% OK, now to get on to the real meat of the data
% here I just prepare some junk that will be needed later, like the names of the different clusters
    disp(sprintf('Analysing cluster data...'))
    cell_names = unique(sdata.uci);

%% For every cell
% here we are going to loop over every cell, this is different to klustest which loops over every tetrode and cluster
% because here we are using the sdata and so already know what clusters are there
    tetrodes = pdata.tetrodes;
    cfig = struct;
    for kk = 1:length(cell_names)
        % get this cell's details
        uci = cell_names{kk}; % this is the unique name for this cell
        disp(sprintf('\tCluster %s...',num2str(uci)));
        shuffled_rate_maps = {};

        % get the tetrode and cluster of the cell
        tet = sdata.tet(find(strcmp(sdata.uci,uci),1,'first'));
        clu = sdata.clu(find(strcmp(sdata.uci,uci),1,'first'));

        % if this isnt a tetrode or cluster we want, skip it
        clusters = pdata.clusters{tet};
        if ~ismember(tet,tetrodes) || ~ismember(clu,clusters) || ~clu
            continue
        end

%% For each part     
        % now, for every cell, we are also going to loop over every part/session so we can analyse the spikes that
        % occured in just one recording session for instance.  
        for pp = 1:nparts % for every partition  
            % part_now is a very useful variable, it tells us the name of the current part and can be used to
            % index into part_config where a lot of the data are stored
            part_now = part_names{pp}; % the name of the current part    
            enow = part_config.environment(pp);
            ename = envset.enames{enow};    
            rnow = part_config.rotation(pp); 
            
            % sort out environment data
            enow = part_config.environment(pp);
            if enow == 0 % if this should be ignored, skip it
                continue
            end     
            disp(sprintf('\t\t%s - %s - %d',part_now,ename,rnow));
            
%             if double(part_now)>103
%                 continue 
%             end 

            %% retrieve position and spike data
            % again we are just getting the data which have already been saved to sdata which saves a lot of time
            % typically, pox and poy are all the position x and y data recorded, whereas ppox and ppoy are the position x and y
            % recorded in this part only, same for spx and pspx
            % I save the data as int16 or single to save space when sdata is saved, so we have to convert to double here so inpolygon etc works
            ppox = double(pdata.(part_now).pox);  
            ppoy = double(pdata.(part_now).poy);  
            ppot = double(pdata.(part_now).pot);              
            ppoh = double(pdata.(part_now).poh);  
            ppoc = double(pdata.(part_now).poc); % compartment index for the position data in this part only
            pspx = pdata.pox(sdata.spike_index{strcmp(sdata.uci,uci) & strcmp(sdata.part,part_now)});
            pspy = pdata.poy(sdata.spike_index{strcmp(sdata.uci,uci) & strcmp(sdata.part,part_now)});
            pspt = sdata.spike_times{strcmp(sdata.uci,uci) & strcmp(sdata.part,part_now)};
            psph = pdata.poh(sdata.spike_index{strcmp(sdata.uci,uci) & strcmp(sdata.part,part_now)});    

            if numel(pspx)< 65 % if the number of spike in a given trial is less than 50, mean FR < 0.1Hz
                disp(sprintf('\b ...too few spikes, skipped'));
                sdata.compartment_index{strcmp(sdata.uci,uci) & strcmp(sdata.part,part_now)} = [];             
                continue
            end

            %% load environment polygons from sdata
            % remember that epoly is the entire environment, comp_poly is a cell array of environments tested by contest
            epoly = pdata.(part_now).epoly;
            comp_poly = pdata.(part_now).comp_poly;

            %% Convert epoly to coordinate lists we can use for analysis later
            lx = epoly(:,1);
            ly = epoly(:,2);
            moy = [];
            mox = [];
            dfactor = 5; % downscaling of environment coordinates, 1 means cm resolution which is accurate but slow 
            for i = 1:length(lx)-1
                x = lx([i i+1]);
                y = ly([i i+1]);
                nPoints = ceil((max(abs(diff(x)), abs(diff(y)))+1)./dfactor);
                moy = [moy linspace(y(1),y(2),nPoints)];
                mox = [mox linspace(x(1),x(2),nPoints)];
            end    
            mox = mox(:);
            moy = moy(:);              

%% Construct egocentric boundary ratemaps (EBR)
% From Alexander et al. (2019) Egocentric boundary vector tuning of the retrosplenial cortex
% http://dx.doi.org/10.1101/702712
%     Construction of egocentric boundary ratemaps. Egocentric boundary ratemaps (EBR) were
%     computed in a similar manner as 2D spatial ratemaps but referenced relative to the animal
%     rather than the spatial environment. The position of the boundaries relative to the animal was
%     calculated for each position sample (i.e. frame). For each frame, we found the distance, in
%     2.5cm bins, between arena boundaries and angles radiating from 0� to 360� in 3� bins relative to
%     the rat�s position. Critically, angular bins were referenced to the current movement direction of
%     the animal such that 0�/360� was always directly in front of the animal, 90� to its left, 180�
%     directly behind it, and 270� to its right. Intersections between each angle and environmental 
%     boundaries were only considered if the distance to intersection was less than or equal to � the
%     length of the most distant possible boundary (in most cases this threshold was set at 62.5cm or
%     half the width of the arena). In any frame the animal occupied a specific distance and angle
%     relative to multiple locations along the arena boundaries, and accordingly, for each frame, the
%     presence of multiple boundary locations were added to multiple 3� x 2.5cm bins in the
%     egocentric boundary occupancy map. The same process was completed with the locations of
%     individual spikes from each neuron, and an EBR was constructed by dividing the number of
%     spikes in each 3� x 2.5cm bin by the amount of time that bin was occupied in seconds.
%     Smoothed EBRs were calculated by convolving each raw EBR with a 2D Gaussian kernel (5 bin
%     width, 5 bin standard deviation).

%% For all position data points get the HD
            alpha = diff(ppoh); % here alpha is the head direction 
            pdata.(part_now).ego_alpha = alpha;
            
%% For all position data points get the distance to the maze boundaries (polar dwell time map)
            interp_angs = 1.5:3:360;
            if isfield(pdata.(part_now),'allocentric_position_data')
                allo_adata = pdata.(part_now).allocentric_position_data;
                ego_adata = pdata.(part_now).egocentric_position_data;        
            else
                disp(sprintf('\t\t\t...generating distance x direction dwell map (%d frames)',numel(ppox)));                
                allo_adata = NaN(length(ppox),length(interp_angs));
                ego_adata = NaN(length(ppox),length(interp_angs));
                loopout = looper(length(ppox));
                for px = 1:length(ppox) % for every position data point (frame)
                    % Find which maze walls are visible from the current position
                    % prepare coordinates for testing intersections      
                    xn = ppox(px);
                    yn = ppoy(px);
                    xy1 = [mox(1:end-1) moy(1:end-1) mox(2:end) moy(2:end)];           
                    xy2 = [repmat(xn,length(mox),1) repmat(yn,length(mox),1) mox(:) moy(:)];

                    % find intersections between angular spokes and environment walls
                    % find points with more than 1 intersection between them and the animals's position
                    % i.e. non-visible walls
                    int = lineSegmentIntersect(xy1,xy2);  
                    admat = int.intAdjacencyMatrix;
                    cut1 = triu(admat,2) + tril(admat,-2);
                    idx = ~logical(sum(cut1,1));
                    mox2 = mox(idx);
                    moy2 = moy(idx);

                    % calculate the distance from the point to all boundaries   
                    an = alpha(px);
                    dmap = sqrt(sum(([mox2 moy2]-[xn yn]).^2,2));

                    % Calculate the angle from the point to all boundaries
                    amap = atan2d(moy2-yn,mox2-xn);
                    amap2 = amap - an; 

                    % interpolate to find the distance to boundaries in 3
                    % degree increments (allocentric reference) 
                    avec = [amap(:)-360;amap(:);amap(:)+360];
                    dvec = [dmap(:);dmap(:);dmap(:)];
                    [avec,idx] = unique(avec);
                    dvec = dvec(idx);
                    dist_at_angles = interp1(avec,dvec,interp_angs,'linear');
                    allo_adata(px,:) = dist_at_angles;

                    % interpolate to find the distance to boundaries in 3
                    % degree increments (egocentric reference) 
                    avec = [amap2(:)-360;amap2(:);amap2(:)+360];
                    dvec = [dmap(:);dmap(:);dmap(:)];        
                    [avec,idx] = unique(avec);
                    dvec = dvec(idx);        
                    dist_at_angles = interp1(avec,dvec,interp_angs,'linear');
                    ego_adata(px,:) = dist_at_angles;

                    % display progress
                    loopout = looper(loopout);
                end

                % accumulate data in pdata
                pdata.(part_now).allocentric_position_data = allo_adata;
                pdata.(part_now).egocentric_position_data = ego_adata;    
                save([pwd '\klustest\' config.cname '\' config.cname '_pdata.mat'],'pdata','-v7.3'); % save session data
            end
            
%% Bin this data to generate dwellmaps in allocentric and egocentric coordinates     
% From Alexander et al. (2019) Egocentric boundary vector tuning of the retrosplenial cortex
% http://dx.doi.org/10.1101/702712        
% Egocentric boundary ratemap generation: Egocentric boundary ratemaps were designed based on the same principle as 
% the allocentric spatial ratemap, but instead of considering the data in an allocentric reference frame where the 
% rat�s position is considered relative to a static spatial environment (Supplementary Fig. 3a�d), the data were 
% considered in an egocentric reference frame where the boundary position was considered relative to a static rat 
% position (Supplementary Fig. 3e�j). The primary components used to generate the egocentric boundary ratemaps are the 
% animal�s movement direction and the boundary position relative to the animal. The instantaneous derivative of the 
% continuous position signal (x/y coordinates) served as the movement direction of the animal. The position of the boundaries 
% relative to the animal was calculated on a frame-by-frame basis. The 360� around the animal was divided into 3� angular 
% bins centered (0�) on the animal�s current instantaneous heading and the distance from the animal�s current position was 
% divided into 2.5?cm distance bins up to a maximum distance of � the length of the longest boundary, yielding 3�?�?2.5?cm 
% bins (Supplementary Fig. 3e�j). For each frame, the presence of a boundary in each bin is counted resulting in an 
% egocentric boundary occupancy map (Supplementary Fig. 3i). Then, for a given cell a density plot of boundary location 
% at the time of spiking is generated using the same 3�?� 2.5?cm bins (Supplementary Fig. 3h). Occupancy normalized 
% egocentric boundary ratemaps were then generated as the element wise division of the spike density by occupancy, 
% which was then smoothed by a 2D gaussian kernel, with a width of 5 bins and standard deviation of 5 bins (Supplementary 
% Fig. 3j).     
            % prepare bins
            angle_bin_edge = 0:3:360; 
            if enow == 1 
                distance_bin_edge = 0:2:40; % for small circular arena, the max distance = 1/2 diameter
%                 distance_bin_edge = 0:2.5:50; % for big circular arena, the max distance = 1/2 diameter
            elseif enow == 4  % also for 4-box the max should be 30 cm
                distance_bin_edge = 0:1.5:30;
            elseif enow == 3  % for empty new square box max - 50cm 
                distance_bin_edge = 0:2.5:50;
            elseif enow == 2
                distance_bin_edge = 0:3:60; % for 2-box, the max distance = 60 cm 
            end 
            angs = repmat(interp_angs,length(ppox),1);

            % accumulate data in sdata
            pdata.(part_now).angle_bin_edge = angle_bin_edge;
            pdata.(part_now).distance_bin_edge = distance_bin_edge;

            smoo = 2;    
            if isfield(pdata.(part_now),'allocentric_dwellmap')
                allo_dmap = double(pdata.(part_now).allocentric_dwellmap);
                ego_dmap = double(pdata.(part_now).egocentric_dwellmap);     
                allo_dmap_half1 = double(pdata.(part_now).allocentric_dwellmap_half1);
                ego_dmap_half1 = double(pdata.(part_now).egocentric_dwellmap_half1);         
                allo_dmap_half2 = double(pdata.(part_now).allocentric_dwellmap_half2);
                ego_dmap_half2 = double(pdata.(part_now).egocentric_dwellmap_half2);  

                allo_dmap_smoo = double(pdata.(part_now).allocentric_dwellmap_smoothed);
                ego_dmap_smoo = double(pdata.(part_now).egocentric_dwellmap_smoothed);     
                allo_dmap_half1_smoo = double(pdata.(part_now).allocentric_dwellmap_half1_smoothed);
                ego_dmap_half1_smoo = double(pdata.(part_now).egocentric_dwellmap_half1_smoothed);         
                allo_dmap_half2_smoo = double(pdata.(part_now).allocentric_dwellmap_half2_smoothed);
                ego_dmap_half2_smoo = double(pdata.(part_now).egocentric_dwellmap_half2_smoothed);         
            else    
                % bin data
                allo_dmap = histcounts2(allo_adata(:),angs(:),distance_bin_edge,angle_bin_edge) .* (1/50);
                ego_dmap = histcounts2(ego_adata(:),angs(:),distance_bin_edge,angle_bin_edge) .* (1/50);

                % half maps
                midtime = median(ppot);
                idx = ppot<midtime;
                allo_dmap_half1 = histcounts2(allo_adata(idx,:),angs(idx,:),distance_bin_edge,angle_bin_edge) .* (1/50);
                ego_dmap_half1 = histcounts2(ego_adata(idx,:),angs(idx,:),distance_bin_edge,angle_bin_edge) .* (1/50);        
                idx = ppot>=midtime;
                allo_dmap_half2 = histcounts2(allo_adata(idx,:),angs(idx,:),distance_bin_edge,angle_bin_edge) .* (1/50);
                ego_dmap_half2 = histcounts2(ego_adata(idx,:),angs(idx,:),distance_bin_edge,angle_bin_edge) .* (1/50);         

                allo_dmap_smoo = imgaussfilt(allo_dmap,smoo,'FilterSize',[5 5],'Padding','circular');
                ego_dmap_smoo = imgaussfilt(allo_dmap,smoo,'FilterSize',[5 5],'Padding','circular');   
                allo_dmap_half1_smoo = imgaussfilt(allo_dmap_half1,smoo,'FilterSize',[5 5],'Padding','circular');
                ego_dmap_half1_smoo = imgaussfilt(ego_dmap_half1,smoo,'FilterSize',[5 5],'Padding','circular');      
                allo_dmap_half2_smoo = imgaussfilt(allo_dmap_half2,smoo,'FilterSize',[5 5],'Padding','circular');
                ego_dmap_half2_smoo = imgaussfilt(ego_dmap_half2,smoo,'FilterSize',[5 5],'Padding','circular');        

                % accumulate data in sdata
                pdata.(part_now).allocentric_dwellmap = single(allo_dmap);
                pdata.(part_now).egocentric_dwellmap = single(ego_dmap);   
                pdata.(part_now).allocentric_dwellmap_half1 = single(allo_dmap_half1);
                pdata.(part_now).egocentric_dwellmap_half1 = single(ego_dmap_half1);          
                pdata.(part_now).allocentric_dwellmap_half2 = single(allo_dmap_half2);
                pdata.(part_now).egocentric_dwellmap_half2 = single(ego_dmap_half2);      

                pdata.(part_now).allocentric_dwellmap_smoothed = single(allo_dmap_smoo);
                pdata.(part_now).egocentric_dwellmap_smoothed = single(ego_dmap_smoo);
                pdata.(part_now).allocentric_dwellmap_half1_smoothed = single(allo_dmap_half1_smoo);
                pdata.(part_now).egocentric_dwellmap_half1_smoothed = single(ego_dmap_half1_smoo);
                pdata.(part_now).allocentric_dwellmap_half2_smoothed = single(allo_dmap_half2_smoo);
                pdata.(part_now).egocentric_dwellmap_half2_smoothed = single(ego_dmap_half2_smoo);    
        
            end

%% Get the cell's egocentric map        
% From Alexander et al. (2019) Egocentric boundary vector tuning of the retrosplenial cortex
% http://dx.doi.org/10.1101/702712        
% Then, for a given cell a density plot of boundary location at the time of spiking is generated using the same 3�?� 2.5?cm bins 
% (Supplementary Fig. 3h). Occupancy normalized egocentric boundary ratemaps were then generated as the element wise division 
% of the spike density by occupancy, which was then smoothed by a 2D gaussian kernel, with a width of 5 bins and standard 
% deviation of 5 bins (Supplementary Fig. 3j).    
            % first get spikes and position data and generate 2D spatial maps
            pspx(pspt<min(ppot) | pspt>max(ppot)) = []; % some spike times are a fraction of a second larger than the max position time, must be an error in Ningyu's version of klustest
            pspy(pspt<min(ppot) | pspt>max(ppot)) = [];
            pspt(pspt<min(ppot) | pspt>max(ppot)) = [];
            sindx = knnsearch(ppot(:),pspt(:));
            pspa = alpha(sindx);
            cfig = struct;
            [rmap2,dmap2,~,cfig] = graphDATA([ppox ppoy],[pspx pspy],[],cfig,'method','histogram');

            % retrieve windows from data that correspond to spikes
            allo_filt = allo_adata(sindx,:);
            ego_filt = ego_adata(sindx,:);
            angs_filt = angs(sindx,:);

            % bin these data to generate spike maps
            allo_smap = histcounts2(allo_filt(:),angs_filt(:),distance_bin_edge,angle_bin_edge);
            ego_smap = histcounts2(ego_filt(:),angs_filt(:),distance_bin_edge,angle_bin_edge);
            [theta,rad] = meshgrid(linspace(min(angle_bin_edge),max(angle_bin_edge),length(angle_bin_edge)-1),linspace(min(distance_bin_edge),max(distance_bin_edge),length(distance_bin_edge)-1));

            % generate firing rate maps
            allo_rmap = imgaussfilt(allo_smap,smoo,'FilterSize',[5 5],'Padding','circular') ./ allo_dmap_smoo;
            ego_rmap = imgaussfilt(ego_smap,smoo,'FilterSize',[5 5],'Padding','circular') ./ ego_dmap_smoo;

%% Get the cell's egocentric values        
% From Alexander et al. (2019) Egocentric boundary vector tuning of the retrosplenial cortex
% http://dx.doi.org/10.1101/702712        
% Egocentric boundary cell classification: The first step in identifying EBCs involved calculating the MRL of each cell�s 
% egocentric boundary directional firing independent of boundary distance (Supplementary Fig. 5b). First, the mean resultant was calculated as
% MR=(??=1n?D=1mF?,D?ei??)/(n?m), (1)
% where ? is the orientation relative to the rat, D is the distance from the rat, F?,D is the firing rate in a given orientation-by-distance 
% bin, n is the number of orientation bins, m is the number of distance bins, e is the Euler constant, and i is the imaginary constant. 
% Then MRL, used as a measure of boundary orientation specificity, is calculated as
% MRL=abs(MR), (2)
% and the mean resultant angle (MRA), which is used as the preferred egocentric boundary orientation, is calculated as
% MRA=arctan2(imag(MR)real(MR)), (3)
% The preferred egocentric boundary distance was calculated along each cell�s preferred egocentric boundary direction MRA by fitting the 
% firing rate vector along that angle with a Weibull distribution and taking the distance bin with the maximum estimated firing rate as the 
% cell�s preferred boundary distance (Supplementary Fig. 5c).  
%
% RG: I decided on this approach instead of the other options because it is more flexible in terms of multiple compartments (like the context box)        
            w = sum(ego_rmap,1); 
            a = deg2rad(histcents(angle_bin_edge)');% bins in radians
            MR = sum(w.*exp(1i*a),2) ./ numel(ego_rmap);
            MRL = abs(MR);
            d = 3*pi/180; % spacing
            c = d/2/sin(d/2);
            MRL = c*MRL;
            MRA = atan2(imag(MR),real(MR));
            MRAd = wrapTo360(rad2deg(MRA));

            % fit a Gaussian to the data along the preferred angle, to get preferred distance
            dt = 0.1:.1:max(distance_bin_edge);
            vec = interp2(theta,rad,double(ego_rmap),ones(size(dt)).*MRAd,dt);
            [xData,yData] = prepareCurveData(dt,vec);
            ft = fittype( 'gauss1' );
            opts = fitoptions( 'Method', 'NonlinearLeastSquares' );
            opts.Display = 'Off';
            opts.Lower = [-Inf 0 0];
            opts.Upper = [Inf max(distance_bin_edge) Inf];    
            opts.StartPoint = [48.112678697573 median(distance_bin_edge) 4.84790219971771];
            [fitresult,~] = fit(xData,yData,ft,opts);  
            MRD = fitresult.b1;

            % get rayleigh vector length of spike angles
            rv = circ_r(deg2rad(pspa(:)));
            xx = wrapTo360(pspa(:).*4);
            rv4 = circ_r(deg2rad(xx));

            % accumulate data in sdata    
            sdindx = strcmp(sdata.uci,uci) & strcmp(sdata.part,part_now);
            sdata.allocentric_spikemap{sdindx} = single(allo_smap);   
            sdata.allocentric_ratemap{sdindx} = single(allo_rmap);   
            sdata.egocentric_spikemap{sdindx} = single(ego_smap);   
            sdata.egocentric_ratemap{sdindx} = single(ego_rmap);   
            sdata.spatial_dwellmap{sdindx} = single(dmap2);            
            sdata.spatial_ratemap{sdindx} = single(rmap2);    

            sdata.mean_resultant(sdindx) = MR;   
            sdata.mean_resultant_length(sdindx) = MRL;   
            sdata.mean_resultant_angle(sdindx) = MRA;   
            sdata.mean_resultant_angle_degrees(sdindx) = MRAd;   
            sdata.mean_resultant_distance(sdindx) = MRD;
            sdata.rayleigh_vector(sdindx) = rv;
            sdata.rayleigh_vector_quadangle(sdindx) = rv4;       

%% Get the cell's map values        
% From Alexander et al. (2019) Egocentric boundary vector tuning of the retrosplenial cortex
% http://dx.doi.org/10.1101/702712            
% Ratemap dispersion, coherence and field size: Ratemap dispersion was calculated as the mean distance between the 
% ratemap bins with the top 10% of firing rates, while ratemap coherence was calculated as the correlation between 
% the firing rate in each bin and the mean firing rate of all adjacent bins. Receptive field size was calculated 
% as the area bounded by contours surrounding bins with firing rates >75% of the bin with the maximum firing rate.     
% 
% RG: It seems to me that they just used the same analyses on spatial ratemaps and direction x distance ratemaps
% I don't see how receptive field size analysis could work on polar histogram data, so I am opting for the total area
% >75% of the maximum instead, this is a little misleading though because this may no longer be one contiguous 'field'
            % allocentric ratemap dispersion
            [i,j] = find(imbinarize(allo_rmap,.9*nanmax(allo_rmap(:)))); % get coordinates of all pixels greater than 90% of maximum
            ds = triu(pdist2([i j],[i j])); % get the pairwise distances between them
            allo_rmap_dispersion = nanmean(ds(ds(:)>0)); % find the mean; these are distances between pixels, so 0 is not possible

            % allocentric ratemap coherence
            f = ones(3,3)./8; % make a filter of ones 3x3
            f(2,2) = 0; % remove the middle because we want the average of surrounding pixels only
            mmap = imfilter(allo_rmap,f,'symmetric'); % perform convolution to get local averages
            allo_rmap_coherence = corr(allo_rmap(:),mmap(:),'rows','pairwise'); % coherence is correlation between original and averaged values

            % allocentric ratemap receptive field size
            allo_rmap_receptive_field = sum(imbinarize(allo_rmap(:),.75*nanmax(allo_rmap(:)))); % total pixels greater than 75% of maximum

            % egocentric ratemap dispersion
            [i,j] = find(imbinarize(ego_rmap,.9*nanmax(ego_rmap(:))));
            ds = triu(pdist2([i j],[i j]));
            ego_rmap_dispersion = nanmean(ds(ds(:)>0));

            % egocentric ratemap coherence
            mmap = imfilter(ego_rmap,f,'symmetric');
            ego_rmap_coherence = corr(ego_rmap(:),mmap(:),'rows','pairwise');

            % egocentric ratemap receptive field size
            ego_rmap_receptive_field = sum(imbinarize(ego_rmap(:),.75*nanmax(ego_rmap(:))));

            % spatial ratemap dispersion
            [i,j] = find(imbinarize(rmap2,.9*nanmax(rmap2(:))));
            ds = triu(pdist2([i j],[i j]));
            rmap2_dispersion = nanmean(ds(ds(:)>0));

            % spatial ratemap coherence
            mmap = imfilter(rmap2,f,'symmetric');
            rmap2_coherence = corr(rmap2(:),mmap(:),'rows','pairwise');

            % spatial ratemap receptive field size
            rmap2_receptive_field = sum(imbinarize(rmap2(:),.75*nanmax(rmap2(:))));

            % accumulate data in sdata
            sdata.allo_rmap_dispersion(sdindx) = allo_rmap_dispersion;
            sdata.allo_rmap_coherence(sdindx) = allo_rmap_coherence;
            sdata.ego_rmap_dispersion(sdindx) = ego_rmap_dispersion;
            sdata.ego_rmap_coherence(sdindx) = ego_rmap_coherence;
            sdata.rmap2_dispersion(sdindx) = rmap2_dispersion;
            sdata.rmap2_coherence(sdindx) = rmap2_coherence;
            sdata.ego_rmap_receptive_field(sdindx) = allo_rmap_receptive_field;
            sdata.rmap2_receptive_field(sdindx) = ego_rmap_receptive_field;
            sdata.rmap2_receptive_field(sdindx) = rmap2_receptive_field;

%% Determine significance of the cell's egocentric values        
% From Alexander et al. (2019) Egocentric boundary vector tuning of the retrosplenial cortex
% http://dx.doi.org/10.1101/702712         
% A shuffling procedure was used in order to obtain an MRL significance threshold for identifying EBCs. The spike train 
% of each cell was shifted by random intervals ranging from 30?s to the full length of the recording minus 30?s relative 
% to the behavioral data. Spike times shifted past the end of the behavioral session data were wrapped around to the 
% beginning of the session. The shifted spike trains maintain the same firing statistics as the original spike train, 
% but the spike times have been dissociated from the animal�s behavior. For each shifted spike train MRL was calculated 
% and this procedure was bootstrapped 100 times for each cell, thus generating a distribution of MRL values from which the 
% 99th percentile was identified and used as a threshold for identifying significant EBCs (Fig. 1f). 
            %if ~ismember('mean_resultant_length_probability',sdata.Properties.VariableNames) || isempty(sdata.mean_resultant_length_probability(sdindx)) || override_shuffles
                disp(sprintf('\t\t\t...MRL shuffle'));  
                [MRLp,p99,mdist,~,ssms] = MRLprob(ppot(:),pspt(:),MRL,ego_adata,angs,distance_bin_edge,angle_bin_edge,ego_dmap_smoo,smoo);
                shuffled_rate_maps{pp,1} = ssms;

                % accumulate data in sdata
                sdata.mean_resultant_length_probability(sdindx) = MRLp;  
                sdata.mean_resultant_length_99_percentile(sdindx) = p99;  
                sdata.mean_resultant_length_shuffle{sdindx} = mdist;
            %end
    
%% Determine significance of the cell's egocentric values        
% From Alexander et al. (2019) Egocentric boundary vector tuning of the retrosplenial cortex
% http://dx.doi.org/10.1101/702712 
% In order to ensure that cells maintained a consistent representation throughout the initial recording session, the session 
% was divided into halves and cells were classified as EBCs if all of the following criteria were met: (1) mean firing rate was 
% >0.1?Hz, (2) MRL for both the 1st and 2nd half was greater than the 99th percentile of the shuffled distribution, (3) the change 
% in MRA between the 1st and 2nd half was <45�, and (4) the change in preferred boundary distance between the 1st and 2nd half was <75% of 
% the preferred distance for the whole session. The cells meeting these criteria were then clustered using the k-means 
% clustering algorithm using firing rate, boundary direction MRL, MRA, preferred boundary distance, PropISIs>2?s (see below), 
% egocentric ratemap coherence, egocentric ratemap dispersion, and field size values ranging from 25 to 85% of the maximum 
% firing rate (10% steps) as features.
            mid_time = median(ppot);
            for x = 0:1
                if ~x
                    pot_now = ppot(ppot<mid_time);
                    spt_now = pspt(pspt<mid_time); 
                    spa_now = pspa(pspt<mid_time);                 
                    sindxnow = sindx(pspt<mid_time);
                    dmap_now = ego_dmap_half1_smoo;
                    append = 'half1';
                else
                    pot_now = ppot(ppot>=mid_time);
                    spt_now = pspt(pspt>=mid_time);   
                    spa_now = pspa(pspt>=mid_time);                   
                    sindxnow = sindx(pspt>=mid_time);
                    dmap_now = ego_dmap_half2_smoo;
                    append = 'half2';                
                end

                % retrieve windows from data that correspond to spikes
                ego_filt_now = ego_adata(sindxnow,:);
                angs_filt_now = angs(sindxnow,:);
                ego_smap_now = histcounts2(ego_filt_now(:),angs_filt_now(:),distance_bin_edge,angle_bin_edge);
                ego_rmap_now = imgaussfilt(ego_smap_now,smoo,'FilterSize',[5 5],'Padding','circular') ./ dmap_now;

                % generate egocentric ratemap and recalculate MRL
                w = sum(ego_rmap_now,1);
                MR_now = sum(w.*exp(1i*a),2) ./ numel(ego_rmap_now);
                MRL_now = abs(MR_now);    
                MRL_now = c*MRL_now;
                MRA_now = atan2(imag(MR_now),real(MR_now));
                MRAd_now = wrapTo360(rad2deg(MRA_now));

                % calculate MRL probability for half session
                %if ~ismember(['mean_resultant_length_probability_' append],sdata.Properties.VariableNames) || isempty(sdata.(['mean_resultant_length_probability_' append])(sdindx)) || override_shuffles
                    disp(sprintf('\t\t\t...MRL %s shuffle',append));                
                    [MRLp,p99,mdist,nshuff,ssms] = MRLprob(pot_now(:),spt_now(:),MRL_now,ego_adata,angs,distance_bin_edge,angle_bin_edge,dmap_now,smoo);
                    shuffled_rate_maps{pp,x+2} = ssms;
                    sdata.(['mean_resultant_length_probability_' append])(sdindx) = MRLp;
                    sdata.(['mean_resultant_length_99_percentile_' append])(sdindx) = p99;
                    sdata.(['mean_resultant_length_shuffle_' append]){sdindx} = mdist;
                %end

                % fit a Gaussian to the data along the preferred angle, to get preferred distance
                dt = 0.1:.1:max(distance_bin_edge);
                vec = interp2(theta,rad,ego_rmap_now,ones(size(dt)).*MRAd_now,dt);
                [xData,yData] = prepareCurveData(dt,vec);
                [fitresult,~] = fit(xData,yData,ft,opts);  
                MRD_now = fitresult.b1;

                % get rayleigh vector length of spike angles
                rv_now = circ_r(deg2rad(spa_now(:)));
                rv4_now = circ_r(deg2rad(spa_now(:).*4));

                % accumulate data
                sdata.(['frate_' append])(sdindx) = numel(spt_now) ./ (numel(pot_now).*(1/50));  
                sdata.(['egocentric_ratemap_' append]){sdindx} = ego_rmap_now;  
                sdata.(['egocentric_spikemap_' append]){sdindx} = ego_smap_now;  
                sdata.(['mean_resultant_' append])(sdindx) = MR_now;                
                sdata.(['mean_resultant_length_' append])(sdindx) = MRL_now;                
                sdata.(['mean_resultant_angle_' append])(sdindx) = MRA_now;                
                sdata.(['mean_resultant_angle_degrees_' append])(sdindx) = MRAd_now;                
                sdata.(['mean_resultant_distance_' append])(sdindx) = MRD_now;                
                sdata.(['rayleigh_vector_' append])(sdindx) = rv_now;
                sdata.(['rayleigh_vector_quadangle_' append])(sdindx) = rv4_now;                 
            end
            sdata.frate(sdindx) = numel(pspt) ./ (numel(ppot).*(1/50));  
   
        end

%% ##################################### Combine the data to get an overall egocentric analysis     
%% Get an index for this cell, including all parts
% Then create averaged egocentric maps so we can calculate an overall egocentric measure
        disp(sprintf('\t\t...combining maps'));  
        mindx = strcmp(sdata.uci,uci) & ismember(sdata.part,part_names);
        % combine all the egocentric ratemaps by averaging
        combined_rmap = sdata.egocentric_ratemap(mindx);
        combined_rmap = nanmean(cat(3,combined_rmap{:}),3);

        % do the same for the first and second halves of the session
        combined_rmap_half1 = sdata.egocentric_ratemap_half1(mindx);
        combined_rmap_half1 = nanmean(cat(3,combined_rmap_half1{:}),3);
        combined_rmap_half2 = sdata.egocentric_ratemap_half2(mindx);
        combined_rmap_half2 = nanmean(cat(3,combined_rmap_half2{:}),3);

        % for each averaged map, calculate the egocentric metrics we need
        mps = {combined_rmap,combined_rmap_half1,combined_rmap_half2};
        MRL_dat = NaN(length(mps),4);
        for ii = 1:length(mps)
            map_now = mps{ii};
            w = sum(map_now,1);
            MR_now = sum(w.*exp(1i*a),2)./ numel(map_now);
            MRL_now = abs(MR_now); 
            MRL_now = c*MRL_now;
            MRA_now = atan2(imag(MR_now),real(MR_now));
            MRAd_now = wrapTo360(rad2deg(MRA_now));        
            vec = interp2(theta,rad,double(map_now),double(ones(size(dt)).*MRAd_now),dt);
            [xData,yData] = prepareCurveData(dt,vec);
            [fitresult,~] = fit(xData,yData,ft,opts);  
            MRD_now = fitresult.b1;             
            % accumulate this info
            MRL_dat(ii,:) = [MRL_now MRA_now MRAd_now MRD_now];     
        end
        
%% Do the same as above but on all the shuffled ratemaps
% This is to generate shuffled distributions which we can use to calculate the probability of egocentricity
        % combine shuffles together so we have one averaged map per shuffle
        % do this for the whole session and the first and second halves
        combined_shuffled_rmaps = zeros([size(combined_rmap) nshuff]);
        combined_shuffled_rmaps_half1 = combined_shuffled_rmaps;
        combined_shuffled_rmaps_half2 = combined_shuffled_rmaps;
        nparts = size(shuffled_rate_maps,1);
        if isempty(shuffled_rate_maps{1,1})
            aa = 2;
        else 
            aa =1;
        end 
        for ii = aa:nparts
            combined_shuffled_rmaps = combined_shuffled_rmaps + cat(3,shuffled_rate_maps{ii,1}{:});
            combined_shuffled_rmaps_half1 = combined_shuffled_rmaps_half1 + cat(3,shuffled_rate_maps{ii,2}{:});
            combined_shuffled_rmaps_half2 = combined_shuffled_rmaps_half2 + cat(3,shuffled_rate_maps{ii,3}{:});
        end
        combined_shuffled_rmaps = combined_shuffled_rmaps ./ nparts;
        combined_shuffled_rmaps_half1 = combined_shuffled_rmaps_half1 ./ nparts;
        combined_shuffled_rmaps_half2 = combined_shuffled_rmaps_half2 ./ nparts;
        
        % for each averaged map, calculate the egocentric metrics we need
        mps = {combined_shuffled_rmaps,combined_shuffled_rmaps_half1,combined_shuffled_rmaps_half2};
        MRL_dat_shuff = NaN(nshuff,4,length(mps));
        for jj = 1:length(mps) % for every set of maps (regular shuffle, half1 shuffle and half2 shuffle)
            for ii = 1:nshuff % for every shuffle
                map_now = mps{jj}(:,:,ii);
                w = sum(map_now,1);
                MR_now = sum(w.*exp(1i*a),2)./ numel(map_now);
                MRL_now = abs(MR_now);   
                MRL_now = c*MRL_now;
                MRA_now = atan2(imag(MR_now),real(MR_now));
                MRAd_now = wrapTo360(rad2deg(MRA_now));        
                vec = interp2(theta,rad,map_now,ones(size(dt)).*MRAd_now,dt);
                [xData,yData] = prepareCurveData(dt,vec);
                [fitresult,~] = fit(xData,yData,ft,opts);  
                MRD_now = fitresult.b1;             
                % accumulate this info
                MRL_dat_shuff(ii,:,jj) = [MRL_now MRA_now MRAd_now MRD_now];     
            end 
        end
        
        % accumulate data in sdata
        sdindx = find(strcmp(sdata.uci,uci),1,'first');
        sdata.combined_egocentric_ratemap{sdindx} = combined_rmap;
        sdata.combined_egocentric_ratemap_half1{sdindx} = combined_rmap_half1;
        sdata.combined_egocentric_ratemap_half2{sdindx} = combined_rmap_half2;
        sdata.combined_egocentric_metrics{sdindx} = MRL_dat;
        sdata.combined_shuffle_egocentric_metrics{sdindx} = MRL_dat_shuff;

%% ##################################### Figure with 1 cells per page       
        figEBCcell
        
    end
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Finish up
    % Save the session data structure
    info = whos('sdata');
    siz = info.bytes / 1000000;
    disp(sprintf('\t...saving %.1fMb sdata',siz))
    save([pwd '\klustest\' config.cname '\' config.cname '_sdata.mat'],'sdata','-v7.3'); % save session data
    save([pwd '\klustest\' config.cname '\' config.cname '_pdata.mat'],'pdata','-v7.3'); % save session data

    % final messages
    toc1 = toc/60;
    disp(['Go to ','<a href = "matlab: [s,r] = system(''explorer ',pwd,' &'');">','current folder','</a>'])
    disp(['Go to ','<a href = "matlab: [s,r] = system(''explorer ',[pwd '\klustest\' pdata.combined_name],' &'');">','Figures folder','</a>'])
    disp(sprintf('egotest has finished. It took %0.3f seconds or %0.3f minutes',toc,toc1)) % Stop counting time and display results
    disp(sprintf('Done.'));
    disp('-------------------------------------------------------------------------------------');






















    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    







