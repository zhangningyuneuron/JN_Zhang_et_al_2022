function partsizeok = bsspartitionsizeok(n)
% BSSPARTITIONSIZEOK - Check the nominal partition size for a B-spline
% series for validity
%
% INPUTS:
%
%    n:
%       The nominal partition size or the number of subintervals to
%       use for the partition in each dimension.
%
%       The partition size for each dimension does NOT include the extra
%       subintervals that are created based on the order of the B-splines
%       that are used.
%
%       This is a row or column vector with NDIM elements.
%
%       NDIM must be 1, 2, or 3. (not currently checked)
%
%       N must:
%
%         be nonempty
%         be numeric
%         be row or column vector
%         have n(i) >= 3, i = 1:NDIM
%         and have n(i) be whole numbers, i = 1:NDIM
%
% OUTPUTS:
%
%   partsizeok:
%      A logical flag indicating whether N passed (1) or failed (0) its
%      validation tests.
%

%
% Copyright 2014-2018 Biometrics Northwest LLC
%

%
% Created: 2014-11-25
% Author : Kevin R. Gehringer
%

%
% Define an initial value that is false.
%
partsizeok = 0;

%
% Begin the testing with nonempty and numeric.
%
if ( isempty(n) )
   error('The B-spline series partition size was empty.');
end

if ( ~isnumeric(n) )
   error('The B-spline series partition size was not numeric.');
end

%
%  Check to see if N is a row or column vector. If it is a row vector,
%  transpose it. 
%
if ( ~iscolumn(n) )
   if ( isrow(n) )
      n = n';
   else
      error('The B-spline series partition size was not a column vector or a row vector.');
   end
end

%
% Get the number of dimensions from the partition size and check.
% Only values of 1, 2, or 3 are valid.
%
%ndim_n = size(n,1);
%if ( ndim_n < 1 || ndim_n > 3 )
%   error('The number of dimensions used for the B-spline series must be 1, 2, or 3, and a value of %d was found for the partition size.',ndim_n);
%end

%
% Check for enough points to specify a partition: 3 are necessary: end
% points and one in middle.
%
row_ids = (1:length(n))';

n_nok = n < 3;
if ( any( n_nok ) )
   error('The partition size for the B-Spline series was not valid for row %d: %g < 3.\n', ...
   [row_ids(n_nok) n(n_nok)]');
end

%
% Check to see that all values are whole numbers by rounding toward zero.
%
row_ids = (1:length(n))';

n_nok = (n-fix(n)) ~=0;
if ( any( n_nok ) )
   error('The partition size for the B-Spline series was not an integer for row %d: %g.\n', ...
   [row_ids(n_nok) n(n_nok)]');
end

%
% The validation tests were passed, set output value to true.
%
partsizeok = 1;
