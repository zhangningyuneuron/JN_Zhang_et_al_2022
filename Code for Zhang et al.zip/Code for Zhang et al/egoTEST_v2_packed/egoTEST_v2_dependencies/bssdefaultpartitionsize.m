function npart = bssdefaultpartitionsize()
%BSSDEFAULTPARTITIONSIZE B-Spline basis function default partition size.
%
%         BSSDEFAULTPARTITIONSIZE returns the current default partition size.
%         The partition size is the nominal number of uniform subintervals
%         used for a partition of a dimension for B-spline series. This
%         does NOT include the extra subintervals needed based on the order
%         of the B-spline basis functions used.
%
%         The partition size for a B-Spline series partition must be a
%         positive integer, NPART > 0. 
%

%
% Copyright 2014-2018 Biometrics Northwest LLC
%

%
% Created: 2014-11-25
% Author : Kevin R. Gehringer
%

npart = 10;
