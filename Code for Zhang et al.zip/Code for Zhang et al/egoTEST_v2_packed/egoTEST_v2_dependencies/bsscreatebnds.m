function bnds = bsscreatebnds(x)
% BSSCREATEBNDS - Create the BNDS array for the B-spline series from data.
%
% INPUTS:
%
%    x:
%       The data to be used for the B-Spline density estimation. This
%       must be a column oriented array with each row representing a data
%       point, X(NDATA,NDIM) in size.
%
%    The input are assumed to be of the correct type and shape. No error
%    checking is performed in this function.
%
% OUTPUTS:
%
%
%    bnds:
%       The lower and upper bounds for the estimation interval over which
%       the bspline series is to be created for evaluation.
%

%
% Copyright 2014-2018 Biometrics Northwest LLC
%

%
% Created: 2014-11-25
% Author : Kevin R. Gehringer
%

%
% Compute the bounds values. 
%
bnds_expand = 0.25;

bnds_min  = min(x);
bnds_max  = max(x);
bnds_adj  = bnds_expand*(bnds_max - bnds_min);
bnds(:,1) = bnds_min - bnds_adj;
bnds(:,2) = bnds_max + bnds_adj;
