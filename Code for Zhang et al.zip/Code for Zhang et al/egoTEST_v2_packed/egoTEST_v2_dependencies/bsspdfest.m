function bss = bsspdfest(x, bnds, n, m, bss)
%BSSPDFEST1D - Estimate a B-Spline series probability density function.
%
% INPUTS:
%
%    x:
%       The data to be used for the B-Spline density estimation. This
%       must be a column oriented array with each row representing a data
%       point, X(NDATA,NDIM) in size. Values of X outside the estimation
%       bounds are ignored.
%
%    bnds:
%       The lower and upper bounds of the estimation interval for each
%       dimension. This is an NDIM by 2 matrix, specifying the minimum and
%       maximum values used to create the B-spline series partition for
%       each dimension.
%
%       If empty or not present, the estimation bounds are generated from
%       the data using bsscreatebnds().
%
%       If any of the bounds are active, a boundary correction is made
%       using reflection through each active boundary. For 2- and
%       3-dimensional data reflection based corrections are also made for
%       corners and edges where multiple boundaries are active.
%
%    n:
%       The nominal partition size or the number of subintervals to use for
%       the partition in each dimension. The partition size for each
%       dimension does NOT include the extra subintervals that are created
%       based on the order of the B-splines that are used. This is a row or
%       column vector with NDIM elements. NDIM must be >=1.
%
%       If empty or not present, the default value obtained from the
%       function bsspartitionsize() and the number of data points is used
%       for each dimension.
%
%    m:
%       The order of the bsplines to be used. This must be an integer
%       scalar value greater than zero (M>=1).
%
%       If not present or empty, the default value is obtained from the
%       function bssdefaultorder().
%
%    bss:
%       An existing B-Spline series probability density estimate
%       that is to have more data points added to it. This allows one
%       to build a B-Spline density estimate a little bit at a time.
%
%       If this argument exists, then BNDS, N, and M are ignored and the
%       values in BSS are used.
%
% OUTPUTS:
%
%    bss_struct:

%       A B-Spline series data structure with the following fields.
%
%          m         - The order of the B-spline basis functions. This is a scalar
%                      value that is the same for all dimensions.
%          ndim      - The number of dimensions for the B-spline series.
%          npts      - The number of data points used to compute the coefficients.
%                      each dimension, including the extra subintervals that
%                      are created based on the order of the B-splines that
%                      are used.
%          bnds      - The estimation bounds for each dimension.
%          partition - The partition structure containing fields X, N, NPART, and H.
%                      The fields represent the partition of the estimation interval
%                      for each dimension, with X defining the boundary points for
%                      the partition subintervals, N defining the nominal partition
%                      size, NPART defining the number of boundary points, and H
%                      defining the width of the subintervals for each dimension.
%          c         - The coefficient matrix for the B-spline series
%

%
% Copyright 2014-2018 Biometrics Northwest LLC
%

%
% Modified: 2016-09-14
% Author : Kevin R. Gehringer
%
%    Updated documentation to indicate that boundary corrections are made
%    for dimensions <= 3.
%
% Modified: 2016-09-14
% Author : Kevin R. Gehringer
%
%    Consolidated the input checking and b-spline series creation into a
%    single function called BSSCHECKINPUTS(). Any arguments that are not
%    supplied are assigned empty alues and passed into the input checker.
%
% Modified: 2016-08-11
% Author : Kevin R. Gehringer
%
%    Fixed a bug when checking the B-spline order. The bsspartitionsizeok()
%    function was called by mistake. It should have been the bssorderok()
%    function.
%
% Modified: 2016-05-01
% Author  : Kevin R. Gehringer
%
%    Added a feature to increase the partition size based on the magnitude
%    of the standard deviation. If the standard deviation is bigger than
%    one, multiply the partition size by half the standard deviation,
%    otherwise keep it the same.
%
%    Note: at some point it may be useful to consider the width of the
%    range of the data in addition to, or instead of, the standard
%    deviation.
%
% Created: 2014-11-25
% Author : Kevin R. Gehringer
%

switch (nargin)
    case 1
        bnds = [];
        n    = [];
        m    = [];
        bss  = [];
    case 2
        n    = [];
        m    = [];
        bss  = [];
    case 3
        m    = [];
        bss  = [];
    case 4
        bss  = [];
    case 5
    otherwise
        error('Incorrect number of input arguments');
end

bss = bsspdfcheckinputs(x,bnds,n,m,bss);

%
% Select the right case and compute the values.
%
switch( bss.ndim )
   case 1
      bss = bsspdfest1d(x, bnds, n, m, bss);
   case 2
      bss = bsspdfest2d(x, bnds, n, m, bss);
   case 3
      bss = bsspdfest3d(x, bnds, n, m, bss);
   otherwise
      bss = bsspdfestnd(x, bnds, n, m, bss);
end
