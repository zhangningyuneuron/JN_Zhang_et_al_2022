function cents = histcents(edges)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   This function takes some edges given to hitcounts or similar ang gives back their centres
%   [cents] = histcents(edges)
%
%%%%%%%% Inputs
%   edges = vector of edge values
%
%%%%%%%% Outputs
%   cents = vector of centre values
%
%%%%%%%% Comments
%   27/10/17 created 
%   � Roddy Grieves: rmgrieves@gmail.com
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Get centres
edges = edges(:)';
edges = [edges NaN; NaN edges];
cents = nanmean(edges,1);
cents = cents(2:end-1)';






















