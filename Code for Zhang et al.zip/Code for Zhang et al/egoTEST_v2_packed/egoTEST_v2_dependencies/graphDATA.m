 function [ratemap,dwellmap,spikemap,cfig] = graphDATA(pos,varargin)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% ################################################################# %% DESCRIPTION
%FUNCTION  short descr.
% long descr.
%
% USAGE:
%         [out] = template(in,in2)
%
% INPUT:
%         in - input 1
%         in2 - input 2
%
% OUTPUT:
%    p - output
%
% EXAMPLES:
%
% See also: FUNCTION2 FUNCTION3

% HISTORY:
% version 1.0.0, Release 00/00/00 Initial release
%
% Author: Roddy Grieves
% UCL, 26 Bedford Way
% eMail: r.grieves@ucl.ac.uk
% Copyright 2019 Roddy Grieves

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% ################################################################# %% INPUT ARGUMENTS CHECK
%% Prepare default settings
    def_spk          = [];
    def_dwellmap     = [];        
    def_config       = struct;
    def_method       = 'histogram';    
    expectedmethods  = {'histogram','leutgeb','adaptive','ksde','ksdefft','ash','kadaptive','bspline','test'};
    def_binsize      = 2.5;             
    def_padding      = 0;              
    def_ssigma       = 1.5;
    def_fsize        = [];
    def_smethod      = 1;
    def_mindwell     = 0.001;
    def_mindist      = 5;
    def_maxdist      = 20;
    def_ash          = 10;
    def_kern         = 'biweight';  
    expectedkerns  = {'biweight','epanechnikov','triangular','uniform','box','normal','triangle'};
    def_srate        = 50;
    def_maplims      = [nanmin(pos,[],1) nanmax(pos,[],1)];

%% Parse inputs
    p = inputParser;
    addRequired(p,'pos',@(x) ~isempty(x) && ~all(isnan(x(:))));  
    addOptional(p,'spk',def_spk,@(x) isnumeric(x)); 
    addOptional(p,'dwellmap',def_dwellmap,@(x) isnumeric(x));  
    addOptional(p,'config',def_config,@(x) isstruct(x));  
    addParameter(p,'method',def_method,@(x) any(validatestring(x,expectedmethods)));   
    addParameter(p,'binsize',def_binsize,@(x) isnumeric(x) && isscalar(x));
    addParameter(p,'padding',def_padding,@(x) isnumeric(x) && isscalar(x) && floor(x)==x);
    addParameter(p,'maplims',def_maplims,@(x) isnumeric(x) && numel(x)==4);
    addParameter(p,'ssigma',def_ssigma,@(x) isnumeric(x) && isscalar(x));
    addParameter(p,'fsize',def_fsize,@(x) isnumeric(x) && isscalar(x) && floor(x)==x);    
    addParameter(p,'smethod',def_smethod,@(x) isnumeric(x) && isscalar(x));
    addParameter(p,'mindwell',def_mindwell,@(x) isnumeric(x) && isscalar(x));
    addParameter(p,'mindist',def_mindist,@(x) isnumeric(x) && isscalar(x));
    addParameter(p,'maxdist',def_maxdist,@(x) isnumeric(x) && isscalar(x));
    addParameter(p,'ash',def_ash,@(x) isnumeric(x) && isscalar(x));
    addParameter(p,'kern',def_kern,@(x) any(validatestring(x,expectedkerns)));   
    addParameter(p,'srate',def_srate,@(x) isnumeric(x) && isscalar(x));
    parse(p,pos,varargin{:});

%% Retrieve parameters 
    % if a config structure (like the one output by this function) was passed in as the 4th argument
    % use those settings. Otherwise use the default settings. This is useful if you want to manually
    % specify the settings elsewhere in a structure or if you want to pass a structure to the function 
    % to ensure it uses exactly the same settings
    if ~isempty(fieldnames(p.Results.config))
        cfig = p.Results.config;
        cfig.pos = p.Results.pos;
        cfig.spk = p.Results.spk;
        if ~isfield(cfig,'dwellmap') || isempty(cfig.dwellmap) || all(isnan(cfig.dwellmap(:)))
            cfig.dwellmap = p.Results.dwellmap;
        end
    else
        cfig = p.Results;
    end
    dwell = false;
    
    if ~isfield(cfig,'fsize') || isempty(cfig.fsize)
        cfig.fsize = 2*ceil(2*cfig.ssigma)+1;
    end

%% ##################################### Heading 2
%% #################### Heading 3
%% Heading 4
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% ################################################################# %% Prepare intial data
%% Prepare spike and position data
    pox = double(cfig.pos(:,1));
    poy = double(cfig.pos(:,2)); 
    spx = double(cfig.spk(:,1));
    spy = double(cfig.spk(:,2)); 

    % centre data on the origin (i.e. centre on the mid point of the data convex hull)
    mid_x = mean(cfig.maplims([1 3])); % centre in X
    mid_y = mean(cfig.maplims([2 4])); % centre in Y
    pox = pox - mid_x; 
    poy = poy - mid_y;   
    spx = spx - mid_x; 
    spy = spy - mid_y;  
    mid_x = cfig.maplims([1 3]) - mean(cfig.maplims([1 3]));
    mid_y = cfig.maplims([2 4]) - mean(cfig.maplims([2 4]));
  
    % generate vectors for bin edges, these span from the middle to the extreme X and Y, then we mirror them across each axis
    % the first +binsize is to ensure the vectors always encapsulate all the data
    xvec = 0 : cfig.binsize : ( max(abs(mid_x)) + cfig.binsize + cfig.binsize * cfig.padding ); 
    yvec = 0 : cfig.binsize : ( max(abs(mid_y)) + cfig.binsize + cfig.binsize * cfig.padding );    
    xvec = unique(sort([-xvec xvec],'ascend')); % mirror these vectors and then sort them in ascending order
    yvec = unique(sort([-yvec yvec],'ascend'));

    % project the position and spike data on to the map coordinates
    cfig.map_pos = [single((pox ./ cfig.binsize) + ceil(length(xvec)/2)), single((poy ./ cfig.binsize) + ceil(length(yvec)/2))];
    cfig.map_spk = [single((spx ./ cfig.binsize) + (length(xvec)/2)), single((spy ./ cfig.binsize) + (length(yvec)/2))];
    cfig.xgrid = xvec;
    cfig.ygrid = yvec;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% ################################################################# %% Generate the maps 
    switch cfig.method
%% ##################################### Histogram method
        case {'histogram'}
            %% This method is the most widely used and can be found everywhere in the literature. It is also the most basic and the fastest.
            % Data are literally binned where they are found. After this is done for the position data bin counts are then multiplied by the
            % sampling rate to get time. The ratemap can be the ratio of spikes to time, smoothed or the ratio of smoothed spikes to time. 
            % In the ratemap, bins where the rat spent less than config.mindwell time are set to NaN

            %% generate spikemap and dwellmap if necessary
            % coordinates are backwards so the resulting map has the correct orientation in IJ
            spikemap = histcounts2(spy,spx,yvec,xvec);

            % the dwellmap only needs to be computed if one wasn't provided
            if isfield(cfig,'speedlift') && ~isempty(cfig.speedlift) && ~all(isnan(cfig.speedlift(:)))
                dwellmap = cfig.speedlift; 
                expected_size = [length(yvec)-1,length(xvec)-1];                
                if ~all(size(dwellmap) == expected_size)
                    error(sprintf('Size of provided dwellmap (%s) does not match the expected size {%s)... exiting',mat2str(size(dwellmap)),mat2str(expected_size)));        
                end                
            else
                dwellmap = histcounts2(poy,pox,yvec,xvec) .* (1/cfig.srate);
                if cfig.smethod==1 && cfig.ssigma>0
                    dwellmap = imgaussfilt(dwellmap,cfig.ssigma);
                end
            end                
            dwellmap(dwellmap < cfig.mindwell | isinf(abs(dwellmap))) = NaN;            

            %% generate and smooth ratemap
            % if we want to smooth spikes and time then calculate ratio
            if cfig.smethod==1 && cfig.ssigma>0
                spikemap = imgaussfilt(spikemap,cfig.ssigma);
                ratemap = spikemap ./ dwellmap;    
                
            % if we want to calculate ratio then smooth result
            elseif cfig.smethod==2 && cfig.ssigma>0
                filtWidth = 2*ceil(2*cfig.ssigma)+1;
                imageFilter = fspecial('gaussian',filtWidth,cfig.ssigma);
                ratemap = nanconv(spikemap./dwellmap,imageFilter, 'nanout');                
                
            % if we want no smoothing at all             
            elseif cfig.smethod==3 || cfig.ssigma==0
                ratemap = spikemap ./ dwellmap;     
                
            end

            %% Make sure low dwell times and spurious results are removed for consistency
            spikemap(isnan(dwellmap) | isinf(abs(spikemap))) = NaN;
            ratemap(isnan(dwellmap) | isinf(abs(ratemap))) = NaN;
            cfig.speedlift = dwellmap;

%% ##################################### Leutgeb method     
        case {'leutgeb'}
            %% REF
            % Leutgeb, Leutgeb, Barnes, Moser, McNaughton and Moser (2005) Independent Codes for Spatial and Episodic Memory in Hippocampal Neuronal Ensembles
            % https://doi.org/10.1126/science.1114037
            % Leutgeb, Leutgeb, Moser and Moser (2007) Pattern separation in the dentate gyrus and CA3 of the hippocampus
            % https://doi.org/10.1126/science.1135801

            %% DESCRIPTION IN REF
            % Spatial firing rate distributions (�place fields�) for each wellisolated neuron were constructed in the standard manner by 
            % summing the total number of spikes that occurred in a given location bin (5 by 5 cm), dividing by the amount of time that
            % the animal spent in that location, and smoothing with a Gaussian centered on each bin. The average rate in each bin x was estimated as:
            % [equation in paper]
            % where g is a smoothing kernel, h is a smoothing factor, n is the number of spikes, si the location of the i-th spike, y(t) the location 
            % of the rat at time t, and [0, T) the period of the recording. A Gaussian kernel was used for g and h = 5 cm. Positions more than 5 cm away 
            % from the tracked path were regarded as unvisited.         

            %% SIMPLE DESCRIPTION
            % For every bin we calculate the distance to every spike and every position data point. These distances are weighted with a gaussian so that
            % data close to the bin centre = high and data far away = low. The sum of the spike distances are then divided by the sum of the position
            % distances to obtain firing rate. The standard deviation of the gaussian can be changed, with a result similar to more smoothing in a standard
            % firing rate map. For speed the effect of the gaussian can be clipped at config.maxdist, meaning we have to perform computations only
            % on position data close to each bin

            % prepare bin centres
            [X1,Y1] = meshgrid(histcents(xvec),histcents(yvec)); 
            xcen = X1(:);
            ycen = Y1(:);
            spikemap = zeros(size(X1));
    
            % prepare smoothing coefficients
            coeff1 = (sqrt(2*pi) .* cfig.ssigma);
            coeff2 = (1 ./ (sqrt(2*pi) .* cfig.ssigma));
            
            % the dwellmap only needs to be computed if one wasn't provided
            if isfield(cfig,'speedlift') && ~isempty(cfig.speedlift) && ~all(isnan(cfig.speedlift(:)))
                dwellmap = cfig.speedlift; 
                if ~all(size(dwellmap) == size(X1))
                    error(sprintf('Size of provided dwellmap (%s) does not match the expected size {%s)... exiting',mat2str(size(dwellmap)),mat2str(size(X1))));        
                end                
            else
                dwellmap = zeros(size(X1));                
                dwell = true;
            end  
            
            %% Run through every bin            
            for bb = 1:numel(xcen) % for every bin  
                %% Generate dwellmap if necessary            
                if dwell % if we need a new dwellmap
                    % logical index which we can use to cut position data to within a square with side length config.maxdist of the bin
                    rindx = pox>xcen(bb)-cfig.maxdist & pox<xcen(bb)+cfig.maxdist & poy>ycen(bb)-cfig.maxdist & poy<ycen(bb)+cfig.maxdist;  
                    if ~any(rindx) % if there are no position data within this distance of the bin, leave it and the spikemap empty
                        continue
                    end                     
                    dp = sqrt(sum(([pox(rindx) poy(rindx)]-[xcen(bb) ycen(bb)]).^2,2)); % calculate the distance to every position data point
                    
                    % if this bin is too far from the position data, leave it and the spikemap empty
                    if nanmin(dp) > cfig.mindist
                        continue
                    end 
                    dp_norm = (exp(-0.5 * (dp./cfig.ssigma).^2) ./ coeff1) ./ coeff2; % gaussian weight the distance values
                    
                    % calculate time as the sum of these distances multiplied by sampling rate to scale it correctly with time, accumulate this value in our dwellmap
                    tbin = nansum(dp_norm)*(1/cfig.srate); % time in voxel
                    dwellmap(bb) = tbin; % accumulate data
                end

                %% Create the spikemap in a similar way
                % logical index which we can use to cut spike data to within a square with side length config.maxdist of the bin                
                rindx = spx>xcen(bb)-cfig.maxdist & spx<xcen(bb)+cfig.maxdist & spy>ycen(bb)-cfig.maxdist & spy<ycen(bb)+cfig.maxdist;  
                if ~any(rindx) % if there are no spike data within this distance of the bin, leave it empty
                    continue
                end                   
                ds = sqrt(sum(([spx(rindx) spy(rindx)]-[xcen(bb) ycen(bb)]).^2,2)); % calculate the distance to every spike data point
                ds_norm = (exp(-0.5 * (ds./cfig.ssigma).^2) ./ coeff1) ./ coeff2; % gaussian weight the distance values
                
                % spike count is the sum of these distances, accumulate this value in our spikemap                
                sbin = nansum(ds_norm); % the number of spikes which fall into the bin
                spikemap(bb) = sbin;        
            end
            dwellmap(dwellmap < cfig.mindwell | isinf(abs(dwellmap))) = NaN;            
            ratemap = spikemap ./ dwellmap;

            % make sure there are no weird values in the ratemap
            spikemap(isnan(dwellmap) | isinf(abs(spikemap))) = NaN;
            ratemap(isnan(dwellmap) | isinf(abs(ratemap))) = NaN;
            cfig.speedlift = dwellmap;
            
%% ##################################### Adaptive method     
        case {'adaptive'}
            %% REF
            % Skaggs and McNaughton (1998) Spatial Firing Properties of Hippocampal CA1 Populations in an Environment Containing Two Visually Identical Regions
            % https://doi.org/10.1523/JNEUROSCI.18-20-08455.1998
            % Skaggs, McNaughton, Wilson and Barnes (1996) Theta phase precession in hippocampal neuronal populations and the compression of temporal sequences
            % https://doi.org/10.1002/(SICI)1098-1063(1996)6:2%3C149::AID-HIPO6%3E3.0.CO;2-K

            %% DESCRIPTION IN REF
            % The 64 x 64 pixel firing rate maps were constructed using an �adaptive smoothing� method that has been described in previous publications
            % (Skaggs et al., 1996). Briefly, the method is designed to optimize the tradeoff between blurring error (attributable to averaging together 
            % data from locations with different true firing rates) and sampling error (the statistical error attributable to the limited number of samples available).
            % To calculate the firing rate at a given point, a circle centered on the point is gradually expanded until the following criterion is met:
            % r >= a / (n * sqrt(s))
            % where a is a constant, r is the radius of the circle in pixels, n is the number of 50-msec-long occupancy samples lying within the circle, and s is the
            % total number of spikes contained in those occupancy samples. Once this criterion was met, the firing rate assigned to the point was equal to s/n.
            % For this experiment, a was set to the value 1000.

            %% SIMPLE DESCRIPTION

            % prepare bin centres
            radius = cfig.binsize:1:cfig.maxdist;
            [X1,Y1] = meshgrid(histcents(xvec),histcents(yvec)); 
            xcen = X1(:);
            ycen = Y1(:);           
            ratemap = NaN(size(X1));
            
            % the dwellmap only needs to be computed if one wasn't provided
            if isfield(cfig,'speedlift') && ~isempty(cfig.speedlift) && ~all(isnan(cfig.speedlift(:)))
                dwellmap = cfig.speedlift; 
                if ~all(size(dwellmap) == size(X1))
                    error(sprintf('Size of provided dwellmap (%s) does not match the expected size {%s)... exiting',mat2str(size(dwellmap)),mat2str(size(X1))));        
                end                
            else
                dwellmap = NaN(numel(X1),length(radius));
                dwell = true;
            end             
            
            %% Run through every bin
            for bb = 1:numel(xcen) % for every bin  
                %% Generate dwellmap if necessary  
                if dwell % if we need a dwellmap
                    % logical index which we can use to cut position data to within a square with side length config.maxdist of the bin
                    rindx = pox>xcen(bb)-cfig.maxdist & pox<xcen(bb)+cfig.maxdist & poy>ycen(bb)-cfig.maxdist & poy<ycen(bb)+cfig.maxdist;                  
                    if ~any(rindx) % if there are no position data within this distance of the bin, leave it and the spikemap empty
                        continue
                    end                         
                    dp = sum(([pox(rindx) poy(rindx)]-[xcen(bb) ycen(bb)]).^2,2); % calculate the squared distance to every position data point
                end
                
                % logical index which we can use to cut spike data to within a square with side length config.maxdist of the bin                
                rindx = spx>xcen(bb)-cfig.maxdist & spx<xcen(bb)+cfig.maxdist & spy>ycen(bb)-cfig.maxdist & spy<ycen(bb)+cfig.maxdist;  
                if ~any(rindx) % if there are no spike data within this distance of the bin, leave it empty
                    ratemap(bb) = 0;
                    if dwell % if we are making a dwellmap
                        pos_per_r = sum(dp(:) < radius.^2,1);
                        dwellmap(bb,:) = pos_per_r(:);
                    end
                    continue
                end         
                
                ds = sum(([spx(rindx) spy(rindx)]-[xcen(bb) ycen(bb)]).^2,2); % calculate the squared distance to every spike data point                                    
                if ~any(ds<cfig.maxdist.^2) % if there are no spike data within config.maxdist distance squared of the bin, leave it empty
                    ratemap(bb) = 0;
                    if dwell % if we are making a dwellmap
                        pos_per_r = sum(dp(:) < radius.^2,1);
                        dwellmap(bb,:) = pos_per_r(:);
                    end                    
                    continue
                end                        

                % a little bit of logical expansion to basically count how many position data points and spikes fall within each radius squared
                % this is also why we need a discrete set of radii
                if dwell % if we are making a dwellmap
                    pos_per_r = sum(dp(:) < radius.^2,1);
                    dwellmap(bb,:) = pos_per_r(:);
                else
                    pos_per_r = dwellmap(bb,:);
                end
                
                spk_per_r = sum(ds(:) < radius.^2,1);    
                if ~any(pos_per_r)
                    ratemap(bb) = NaN;
                    continue
                elseif ~any(spk_per_r)
                    ratemap(bb) = 0;
                    continue                        
                end
                criterion = cfig.ssigma./(pos_per_r.*sqrt(spk_per_r));
                criterion(pos_per_r==0 | spk_per_r==0) = NaN;

                % here we satisfy the actual equation and find the smallest radius greater or equal than 1/N*sqrt(s)
                radius_index = find(radius >= criterion,1,'first');
                if isempty(radius_index) % if no radius up to config.maxdist exceeds the criterion, leave this bin empty
                    ratemap(bb) = NaN;
                    continue
                end
                ratemap(bb) = spk_per_r(radius_index) ./ pos_per_r(radius_index);
            end
            
            % make sure there are no weird values in the ratemap
            ratemap(isinf(abs(ratemap))) = NaN;
            cfig.speedlift = dwellmap;
            dwellmap = NaN(size(ratemap));
            spikemap = NaN(size(ratemap));
            
%% ##################################### Kernel smoothed density estimate    
        case {'ksde'}
            % This method uses a multivariate kernel density estimate approach to estimate probability density functions for the position data 
            % and spike data separately. The firing rate map is then calculated as the ratio of these two maps. Here smoothing is achieved using 
            % the bandwidth of the KDE 
            
            % prepare bin centres
            [X1,Y1] = meshgrid(histcents(xvec),histcents(yvec)); 
            xcen = X1(:);
            ycen = Y1(:);
            
            % the dwellmap only needs to be computed if one wasn't provided
            if isfield(cfig,'speedlift') && ~isempty(cfig.speedlift) && ~all(isnan(cfig.speedlift(:)))
                dwellmap = cfig.speedlift; 
                expected_size = [length(ycen),length(xcen)];
                if ~all(size(dwellmap) == expected_size)
                    error(sprintf('Size of provided dwellmap (%s) does not match the expected size {%s)... exiting',mat2str(size(dwellmap)),mat2str(expected_size)));        
                end                
            else
                pos_ksde = mvksdensity([pox,poy],[xcen,ycen],'bandwidth',cfig.ssigma,'Function','pdf','Kernel',cfig.kern,'BoundaryCorrection','reflection');
                pos_ksde = pos_ksde .* (cfig.binsize.^2) .* numel(pox) .* (1/cfig.srate); % convert to probability and then time      
                dwellmap = reshape(pos_ksde,size(X1));
            end  
            dwellmap(dwellmap < cfig.mindwell | isinf(abs(dwellmap))) = NaN;            
            
            %% Generate spikemap and ratemap      
            spk_ksde = mvksdensity([spx,spy],[xcen,ycen],'bandwidth',cfig.ssigma,'Function','pdf','Kernel',cfig.kern,'BoundaryCorrection','reflection');        
            spk_ksde = spk_ksde .* (cfig.binsize.^2) .* numel(spx); % convert to probability and then spikes           
            spikemap = reshape(spk_ksde,size(X1));
            ratemap = spikemap ./ dwellmap;

            % make sure there are no weird values in the ratemap
            spikemap(isnan(dwellmap) | isinf(abs(spikemap))) = NaN;
            ratemap(isnan(dwellmap) | isinf(abs(ratemap))) = NaN;
            cfig.speedlift = dwellmap;
            
%% ##################################### Kernel smoothed density estimate    
        case {'ash'}  
            %% REF
            % David Scott (1992) Multivariate Density Estimation, John Wiley, (chapter 5)
            % https://onlinelibrary.wiley.com/doi/book/10.1002/9781118575574

            %% DESCRIPTION IN REF
            % A simple device has been proposed for eliminating the bin edge problem of the frequency polygon while retaining many of the computational advantages of a density
            % estimate based on bin counts. Scott (1983, 1985b) considered the problem of choosing among the collection of multivariate frequency polygons, each with the same
            % smoothing parameter but differing bin origins. Rather than choosing the �smoothest� such curve or surface, he proposed averaging several of the shifted frequency polygons. 
            % As the average of piecewise linear curves is also piecewise linear, the resulting curve appears to be a frequency polygon as well. If the weights are nonnegative and
            % sum to 1, the resulting �averaged shifted frequency polygon� (ASFP) is nonnegative and integrates to 1. A nearly equivalent device is to average several shifted histograms, 
            % which is just as general but simpler to describe and analyze. The result is the �averaged shifted histogram� (ASH). Since the average of piecewise constant functions such as the
            % histogram is also piecewise constant, the ASH appears to be a histogram as well. In practice, the ASH is made continuous using either of the linear interpolation schemes
            % described for the frequency polygon in Chapter 4, and will be referred to as the frequency polygon (FP) of the (ASH). The ASH is the practical choice for computationally 
            % and statistically efficient density estimation. Algorithms for its evaluation are described in detail.

            %% SIMPLE DESCRIPTION            
            % Histograms are very fast to compute, but kernel smoothed density estimates are more accurate, one tradeoff is to instead calculate a lot of different histograms with slightly 
            % offset bins (i.e. the bin edges are moved with respect to the data by a fraction of 1 bin length). The result is a histogram with a much lower MISE than a single histogram.
            % In practice the result should not need to be smoothed and an added benefit is that the resulting histograms still sum to the number of data points.
            % In reality we don't make multiple histograms but instead make one very fine scale one and then use a special weighting kernel to average across them.

            cfig.ash = ceil(cfig.ash);
            if cfig.ash<2
                cfig.ash = 1;    
            end
            h = cfig.binsize;
            m = cfig.ash;
            delta = h/m; % fine grid increment
            
            % prepare fine bin centres
            xf = min(xvec):delta:max(xvec);
            yf = min(yvec):delta:max(yvec);

            %% create biweight (quartic) filter and apply it to both maps
            s = cfig.ssigma;
            switch cfig.kern
                case {'biweight'}
                    kern = @(x) (15/16)*(1-x.^2).^2;
                case {'epanechnikov'}
                    kern = @(x) (3/4)*(1-x.^2);
                case {'triangular'}
                    kern = @(x) (1-abs(x));                    
                case {'uniform','box'}
                    kern = @(x) ones(size(x)).*.5;
                case {'gaussian','normal'}
                    kern = @(x) 1/(s*sqrt(2*pi)) .* exp(-(x.^2./(2*s.^2)));     
            end
            w = zeros(2*m-1,2*m-1);           
            [r,c] = ind2sub(size(w),1:numel(w));
            w(1:numel(w)) = sqrt(sum(([r(:),c(:)]-mean([r(:),c(:)],1)).^2,2)); % distance within kernel
            wm = kern(w) ./ sum(sum(kern(w)));

            %% generate spikemap and dwellmap if necessary using fine grid
            % coordinates are backwards so the resulting map has the correct orientation in IJ
            s1 = histcounts2(spy,spx,yf,xf);
            spikemap = imfilter(s1,wm,'symmetric','same','conv');
            
            % the dwellmap only needs to be computed if one wasn't provided
            if isfield(cfig,'speedlift') && ~isempty(cfig.speedlift) && ~all(isnan(cfig.speedlift(:)))
                dwellmap = cfig.speedlift; 
                expected_size = [length(yf)-1,length(xf)-1];
                if ~all(size(dwellmap) == expected_size)
                    error(sprintf('Size of provided dwellmap (%s) does not match the expected size {%s)... exiting',mat2str(size(dwellmap)),mat2str(expected_size)));        
                end                
            else
                d1 = histcounts2(poy,pox,yf,xf) .* (1/50);
                cfig.original_maps = cat(3,d1,s1,s1./d1);
                dwellmap = imfilter(d1,wm,'symmetric','same','conv');              
            end  
            dwellmap(dwellmap < cfig.mindwell | isinf(abs(dwellmap))) = NaN;                   

            % generate ratemap
            ratemap = spikemap./dwellmap;   

            % make sure there are no weird values in the ratemap
            spikemap(isnan(dwellmap) | isinf(abs(spikemap))) = NaN;
            ratemap(isnan(dwellmap) | isinf(abs(ratemap))) = NaN;
            cfig.speedlift = dwellmap;     

%% ##################################### Fast adaptive method
        case {'kadaptive'}  
            %% SIMPLE DESCRIPTION            
            % There is no Ref for this method as I don't think it has been proposed before. This mixes the benefits and methods underlying both the average shifted histogram
            % and adaptive binning. We create a fine grid (suggested is 1cm or less binsize) and bin the spike and position data into this, like we do with ASH
            % Then we apply a kernel to this like the ASH but instead of weighting this to average over histograms we sum all the spikes and position data within a series of distances
            % of each bin, like with the adaptive method. Then we apply the same formula as in the adaptive method to every bin, finding the radius for each that meets the criteria
            % Because we bin the data into a fine grid before this process we don't have to compute distances which saves a lot of time and the kernel we use is very simple
            % and can be applied using convolution methods for an overall very fast process which should approximate a KDE
            
            %% generate spikemap and dwellmap if necessary
            %kvect = unique(ceil(linspace(1,config.maxdist,10)));
            kvect = 1:2:cfig.maxdist;
            if isfield(cfig,'speedlift') && ~isempty(cfig.speedlift) && ~all(isnan(cfig.speedlift(:)))
                dwellmap = cfig.dwellmap;
                dmaps = cfig.speedlift;
            else
                % coordinates are backwards so the resulting map has the correct orientation in IJ
                dwellmap = histcounts2(poy,pox,yvec,xvec);            
                dmaps = NaN([size(dwellmap) length(kvect)]);
                for kk = 1:length(kvect)
                    kern = ones(kvect(kk),kvect(kk));
                    dmaps(:,:,kk) = imfilter(dwellmap,kern);                    
                end  
                cfig.speedlift = dmaps;
            end
            
            % coordinates are backwards so the resulting map has the correct orientation in IJ
            spikemap = histcounts2(spy,spx,yvec,xvec);
            smaps = NaN([size(spikemap) length(kvect)]);
            for kk = 1:length(kvect)
                kern = ones(kvect(kk),kvect(kk));
                smaps(:,:,kk) = imfilter(spikemap,kern);                    
            end

            % adaptive equation
            amaps = ones(size(dmaps)).*cfig.ssigma;
            rmaps = amaps ./ (dmaps .* sqrt(smaps));
            distmap = ones(size(dmaps)).*permute(kvect./2,[1 3 2]).*cfig.binsize;
            emaps = distmap>=rmaps;
            
            % fill in the ratemap values
            ratemap = NaN(size(dwellmap));
            for pp = 1:numel(dwellmap)
                [i,j] = ind2sub(size(dwellmap),pp);
                if ~any(emaps(i,j,:))
                    continue
                end
                indx = find(emaps(i,j,:),1,'first');
                ratemap(i,j) = squeeze(smaps(i,j,indx) ./ (dmaps(i,j,indx).*(1/50)));
            end
            cfig.speedlift = dmaps;
            cfig.dwellmap = dwellmap;

%             figure
%             subplot(2,2,1)
%             imagesc(spikemap)
%             daspect([1 1 1])   
% 
%             subplot(2,2,2)
%             imagesc(dwellmap)
%             daspect([1 1 1])  
% 
%             subplot(2,2,3)
%             imagesc(spikemap./(dwellmap.*(1/50)))
%             daspect([1 1 1])
% 
%             subplot(2,2,4)
%             imagesc(ratemap)
%             daspect([1 1 1])            
            
%% ##################################### For testing    
        case {'ksdefft'}
            %% REF
            % Wand (1994) Fast Computation of Multivariate Kernel Estimators
            % https://www.jstor.org/stable/1390904
            % Bruno Luong, FFT-based convolution
            % https://uk.mathworks.com/matlabcentral/fileexchange/24504-fft-based-convolution

            %% DESCRIPTION IN REF
            % Binned kernel estimates are usually computed over an equally-spaced mesh of grid points. The same ideas can be applied to obtain quickly 
            % computable approximations to kernel functional estimates, which arise in many common automatic bandwidth selection algorithms. Their 
            % calculation requires three distinct steps:
            %     1. Bin the data by assigning the raw data to neighboring grid points to obtain grid counts. A grid count can be thought of as representing 
            %     the amount of data in the neighborhood of its corresponding grid point.
            %     2. Compute the required kernel weights. The fact that the grid points are equally spaced means that the number of distinct kernel weights is 
            %     comparatively small.
            %     3. Combine the grid counts and the kernel weights to obtain the approximation to the kernel estimate. This essentially involves a series of 
            %     discrete convolutions.
            % Step 1 requires the choice of both the number of grid points and the binning rule. The first choice is quite crucial, because it represents 
            % a compromise between the computational speed of the algorithm and the approximation error due to binning. There are also several ways to 
            % bin the data (see Hall and Wand, 1993). We describe and compare the multivariate extensions of the two most popular binning rules in Section 4.
            % The multivariate extension of Step 2 can be accomplished quite easily, as explained in Section 2. An important question concerns the most effective 
            % way of executing Step 3. The traditional way of computing a discrete convolution quickly is via the fast Fourier trans-form (FFT). However, direct 
            % computation of convolutions is a contender in the kernel estimation case because the arrays involved typically contain a high proportion of 0's.
            % Scott (1992) presented algorithms that take advantage of this sparseness. In Section 5 we present a comparison of these approaches through an empirical 
            % study. It is demonstrated that, although there is little difference between the computational speeds of FFT and direct computation of convolution in 
            % univariate settings (Fan and Marron 1994), considerable gains can be realized by use of the FFT in multivariate settings.

            %% SIMPLE DESCRIPTION            
            % Histograms are very fast to compute, but kernel smoothed density estimates are more accurate, one tradeoff is to initially calculate a fine scale histogram
            % so that the KSDE can operate on this much reduced (but less acuurate) data. While we are at it we can also speed up this kernel approach by applying it via
            % the FFT algorithm which is much faster (for larger data sets anyway) than linear convolution. The result is a very accurate representation of the underlying
            % density and a very accurate (but fast) representation of a KSDE generated using the raw data.
            % For our purposes initially binning the data makes sense anyway because our data are inherently limited by the resolution of the camera used to track the animal.
            
%             config.ash = ceil(config.ash);
%             if config.ash<2
%                 config.ash = 1;    
%             end
%             h = config.binsize;
%             m = config.ash;
%             delta = h/m; % fine grid increment

%             % prepare fine bin centres
%             xf = min(xvec):delta:max(xvec);
%             yf = min(yvec):delta:max(yvec);
            
            % padding amount for FFT
            padding = 20;    

            % create biweight (quartic) filter
            s = cfig.ssigma;
            m = cfig.fsize;
            switch cfig.kern
                case {'biweight'}
                    kern = @(x) (15/16)*(1-x.^2).^2;
                case {'epanechnikov'}
                    kern = @(x) (3/4)*(1-x.^2);
                case {'triangular'}
                    kern = @(x) (1-abs(x));                    
                case {'uniform','box'}
                    kern = @(x) ones(size(x)).*.5;
                case {'gaussian','normal'}
                    kern = @(x) 1/(s*sqrt(2*pi)) .* exp(-(x.^2./(2*s.^2)));     
            end
            w = zeros(2*m-1,2*m-1);
            [r,c] = ind2sub(size(w),1:numel(w));
            w(1:numel(w)) = sqrt(sum(([r(:),c(:)]-mean([r(:),c(:)],1)).^2,2)); % distance within kernel
            wm = kern(w) ./ sum(sum(kern(w)));

            %% generate spikemap and dwellmap if necessary
            if isfield(cfig,'dwellmap') && ~isempty(cfig.dwellmap) && ~all(isnan(cfig.dwellmap(:)))
                dwellmap = cfig.dwellmap;
            else
                % coordinates are backwards so the resulting map has the correct orientation in IJ
                dmap = histcounts2(poy,pox,yvec,xvec);   
                % pad the dwellmap ready for FFT convolution, apply kernel using FFT (conv2fft from the Matlab FEX, Bruno Luong), remove spurious values
                dmap = padarray(dmap,[padding padding],'symmetric','both');
                if cfig.smethod<3 && cfig.ssigma>0 % if we want to apply smoothing
                    dwellmap = conv2fft(dmap,wm,'same');
                    %dwellmap = conv2(dmap,wm,'same');
                else
                    dwellmap = dmap;
                end
                dwellmap(isinf(abs(dwellmap)) | dwellmap<0) = 0; % remove extreme values caused by rounding errors or the FFT weirding out
            end            
            cfig.dwellmap = dwellmap;
            
            % coordinates are backwards so the resulting map has the correct orientation in IJ
            smap = histcounts2(spy,spx,yvec,xvec);
            % pad the spikemap ready for FFT convolution, apply kernel using FFT (conv2fft from the Matlab FEX, Bruno Luong), remove spurious values
            smap = padarray(smap,[padding padding],'symmetric','both');
            if cfig.smethod<3 && cfig.ssigma>0 % if we want to apply smoothing
                spikemap = conv2fft(smap,wm,'same');
                %spikemap = conv2(smap,wm,'same');                
            else
                spikemap = smap;
            end
            spikemap(isinf(abs(spikemap)) | spikemap<0) = 0; % remove extreme values caused by rounding errors or the FFT weirding out

            % calculate ratemap, remove spurious values
            dwellmap = dwellmap(padding+1:end-padding,padding+1:end-padding) .* (1/50);
            spikemap = spikemap(padding+1:end-padding,padding+1:end-padding);
            ratemap = spikemap ./ dwellmap;            
            ratemap(isnan(dwellmap) | isinf(abs(ratemap))) = NaN;            

%% ##################################### For testing    
        case {'bspline'}            
            %% REF
            % Masri and Redner (2005) Convergence rates for uniform B-spline density estimators on bounded and semi-infinite domains 
            % https://www.math.tamu.edu/~masri/ConvergenceRates.pdf
            % Kevin Gehringer
            % https://uk.mathworks.com/matlabcentral/fileexchange/49121-bsspdfest
            % https://www.biometricsnw.com/projects/bssest/bssest.htm

            %% DESCRIPTION IN REF
            % The nonparametric B-Spline density estimate is a generalization of the histogram density estimate, and like the histogram 
            % it is related to orthogonal series estimators (see Schwartz [1967]). The B-Spline density estimate requires o(N) storage and 
            % if the consistency conditions are satisfied, evaluation at each point can be performed in constant time. Since the density estimate
            % is based on splines, conditional densities can be rapidly generated and the degree of smoothness is easily controlled.

            %% SIMPLE DESCRIPTION            

            
cfig.ssigma = 50;            
            
% prepare bin centres
[X1,Y1] = meshgrid(xvec,yvec); 
xcen = X1(:);
ycen = Y1(:);            
bounds = [min(xvec) max(xvec);min(yvec) max(yvec)];
bins = [length(xvec) length(yvec)];

%% generate spikemap and dwellmap if necessary
if isfield(cfig,'dwellmap') && ~isempty(cfig.dwellmap) && ~all(isnan(cfig.dwellmap(:)))
    dwellmap = cfig.dwellmap;
else
    bss = bsspdfest([pox(:) poy(:)],bounds,bins,cfig.ssigma);
    dwellmap = bsseval([xcen(:) ycen(:)],bss,'pdf');
    dwellmap = reshape(dwellmap,size(X1));
    dwellmap = dwellmap .* numel(pox);
end            
cfig.dwellmap = dwellmap;

% spike map        
bss = bsspdfest([spx(:) spy(:)],bounds,bins,cfig.ssigma);
spikemap = bsseval([xcen(:) ycen(:)],bss,'pdf');
spikemap = reshape(spikemap,size(X1));
spikemap = spikemap .* numel(spx);

% calculate ratemap, remove spurious values
ratemap = spikemap ./ dwellmap .* (1/50);
ratemap(isnan(dwellmap) | isinf(abs(ratemap))) = NaN;  




figure
subplot(2,2,1)
imagesc(spikemap)
daspect([1 1 1])
axis xy

subplot(2,2,2)
imagesc(dwellmap)
daspect([1 1 1])
axis xy

subplot(2,2,3)
imagesc(ratemap)
daspect([1 1 1])
axis xy            
            
            
 keyboard           
            
            
            
    end
    
cfig.ratemap = ratemap;    








% 
% 
%             figure
%             subplot(2,2,1)
%             plot(pox,poy,'k'); hold on;
%             plot(spx,spy,'r.','MarkerSize',10)
%             daspect([1 1 1])
%             axis xy      
% 
%             
%             subplot(2,2,2)
%             im = imagesc(ratemap);
%             set(im,'alphadata',~isnan(ratemap))
%             daspect([1 1 1])
%             axis xy
% 
%             subplot(2,2,3)
%             im = imagesc(spikemap);
%             set(im,'alphadata',~isnan(spikemap))
%             daspect([1 1 1])
%             axis xy
% 
%             subplot(2,2,4)
%             im = imagesc(dwellmap);
%             set(im,'alphadata',~isnan(dwellmap))
%             daspect([1 1 1])
%             axis xy
% 
% 
% 
% 
% 
% keyboard
% 
% 


















