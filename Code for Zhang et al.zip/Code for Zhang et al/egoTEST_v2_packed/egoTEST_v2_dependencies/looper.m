function loopout = looper(loopin)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% ################################################################# %% DESCRIPTION
%looper  function to display a progress amount (% progress in concole)
% This function should be called before a loop, it works out when the best points
% would be to display a progress % (in increments of 10% by default) and then displays
% this during the loop. Primary made for the new version of klustest3
% This function does have a small overhead (0.5s on 100000 loops) which
% I have tried to keep as small as possible. Because it doesn't update on every
% loop and because it uses console text instead of a figure it should be fast
%
% USAGE:
%         loopout = looper(loopin)
%
% INPUT:
%         loopin - when the function is first called this is the number of loops you expect to make, afterwards it is the output of the first call 
%
% OUTPUT:
%    loopout - output of function, should always be returned as the input afterwards
%
% EXAMPLES:
%
%     loops = 123;
%     loopout = looper(loops);
%     for ii = 1:loops
%         loopout = looper(loopout);    
%     end
%
% See also: klustest3 waitbar

% HISTORY:
% version 1.0.0, Release 27/06/19 Initial release
%
% Author: Roddy Grieves
% UCL, 26 Bedford Way
% eMail: r.grieves@ucl.ac.uk
% Copyright 2019 Roddy Grieves

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% ################################################################# %% FUNCTION BODY
if isnumeric(loopin)
    disploops = ceil(linspace(1,loopin,11)); % these are the loops we want to display on
    loopout = struct;
    loopout.numloops = loopin;
    loopout.disploops = disploops;
    loopout.textchain = {'\t\t\t\tprocessing: 0%%','\b 10%%','\b 20%%','\b 30%%','\b 40%%','\b 50%%','\b 60%%','\b 70%%','\b 80%%','\b 90%%','\b 100%% '};
    loopout.start = tic;
    loopout.loop = 1;

else
    loopout = loopin;  
    
    if ~any(loopin.disploops==loopin.loop) % if this is not a display loop just quit to save time        
        loopout.loop = loopin.loop+1;
        return
    end

    idx = find(loopin.disploops==loopin.loop);
    for i = 1:length(idx)
        disp(sprintf(loopin.textchain{idx(i)}))
    end
    
    if loopin.loop==loopin.disploops(end)
        disp(sprintf('\b(%.2fs, %.3fs/loop)',toc(loopin.start),toc(loopin.start)/loopout.numloops))
    end
    loopout.loop = loopin.loop+1;  

end











