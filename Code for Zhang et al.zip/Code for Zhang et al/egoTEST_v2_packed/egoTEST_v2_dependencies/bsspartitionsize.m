function nb = bsspartitionsize(n,ndim)
%BSSPARTITIONSIZE - Compute optimal number of histogram bins for sample size N.
%
% INPUTS:
%
%    n:
%       The number of data points used to estimate the partition size.
%
%    ndim:
%       The number of dimensions in the data. NDIM >=1 and a whole number.
%       If missing, a value of one (1) is assigned.
%
% OUTPUTS:
%
%    nb:
%       An estimate of the optimal number of uniform width bins for a
%       B-spline series using n data points.
%
%       Note that multipliers were determined empirically. The cube root is
%       a theoretical result.
%

%
% Copyright 2014-2018 Biometrics Northwest LLC
%


%
% Modified: 2018-08-28
% Author : Kevin R. Gehringer
%
%     Modified the automatically generated partition sizes making them
%     larger for dimensions greater than one to improve the PDF agreement
%     when not specifying a custom partition size.
%
% Modified: 2016-10-26
% Author : Kevin R. Gehringer
%
%   Changed all of the multipliers to improve the smoothness of continuous
%   distributions slightly.  There are still too many, but erring on the
%   side of undersmoothing is the right way to go.
%
% Modified: 2016-04-02
% Author : Kevin R. Gehringer
%
%   Changed the multiplier on N^(-1/3) from 2 to 3. This improves the 1-D
%   approximation.
%
% Created: 2014-11-25
% Author : Kevin R. Gehringer
%

if ( ~isnumeric(n) )
     error('The number of data points was not numeric.');
end

n = floor(n);

if ( n < 1 )
     error('The number of data points must be at least 1.');
end

if ( exist ('ndim','var') )
    if ( ~isnumeric(ndim) )
         error('The number of dimensions was not numeric.');
    end
    ndim = floor(ndim);
    if (ndim < 1 )
        error('The number of dimensions must be at least 1.');
    end
else
    error('Too few input arguments: The number of dimensions NDIM was not provided.');
end

switch ndim
    case 1
%        nb = 1+floor(2.5*n.^(1/3));
        nb = 1+floor(2.0*n.^(1/3));
    case 2
%        nb = repmat(1+floor(n.^(1/3)),ndim,1);
        nb = repmat(1+floor(1.5*n.^(1/3)),ndim,1);
    case 3
%        nb = repmat(1+floor(0.95*n.^(1/3)),ndim,1);
        nb = repmat(1+floor(1.3*n.^(1/3)),ndim,1);
    otherwise
%        nb = repmat(1+floor(0.80*n.^(1/3)),ndim,1);
        nb = repmat(1+floor(1.1*n.^(1/3)),ndim,1);
end

