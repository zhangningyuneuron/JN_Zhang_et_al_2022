function [xgrid,ygrid,h] = bsscreateinterpolant(bss,evalfun)
%BSSCREATEINTERPOLANT Create an interpolant grid for a PDF or CDF
%
% INPUTS:
%
%    bss:
%       The B-Spline series data structure containing the series to be used
%       for evaluation and the creation of the grid.
%
%    evalfun:
%       The function that is to be evaluated. If the B-Spline series
%       represents a probability density function, the output functions
%       'pdf' and 'cdf' are available for the grid.
%
%       If no evaluation function is specified the B-Spline series is
%       simply evaluated without transformations to generate the grid. An
%       evaluation function of 'bss' may also be used to specify this
%       behavior.
%
%       Allowed evaluation functions if the B-Spline series represents a
%       probability density function:
%
%          pdf      : The probability density function, f(x)
%          cdf      : The cumulative distribution function, F(x)
%
% OUTPUTS:
%
%    xgrid:
%       A grid generated from the B-spline series evaluation bonds in BSS.
%       The grid is stored as a one dimensional cell array, or compact
%       grid, with the grid values for each dimension stored in the cell
%       array elements.
%
%    ygrid:
%       Values associated with the data grid in XGRID. These are generated
%       from the B-spline series BSS and can represent an arbitrary
%       function, a PDF, or a CDF.
%
%    h:
%       The uniform spacing between the grid points in each dimension.
%

%
% Copyright 2014-2018 Biometrics Northwest LLC
%

%
% Modified: 2018-08-28
% Author  : Kevin R. Gehringer
%
%     Changed the name of a varialbe from 'ngrid' to 'tmpngrid. MATLAB has
%     a function called 'ngrid' that caused a potentlai conflict.
%
% Created: 2016-05-14
% Author : Kevin R. Gehringer
%

%
% We gotta have a B-spline series structure.
%
if ( ~exist('bss','var') )
   error('The B-spline series data structure was not provided.');
end

if ( isempty(bss) )
   error('The B-spline series data structure was empty.');
end

%
%   Check to see if an evaluation function was specified. If not, assign
%   the default 'bss'.
%
if ( ~exist('evalfun','var') )
    evalfun = 'bss';
end

%
% Validate the evaluation function. Valid values are: 'bss', 'pdf', and
% 'cdf'.
%
okfuns = {'bss';'pdf';'cdf'};
if ( ~any(strcmpi(evalfun,okfuns)) )
    error('The evaluation function ''%s'' was not recognized.',evalfun);
end

%
% Compute the size for the gridded interpolant.
%
tmpngrid = floor(bsspointsperpartition(bss.ndim)*bss.partition.n)+1;

%
% Check available memory to see if the gridded interpolant will likely fit
%
bsscheckmemory(tmpngrid,'grid');

if (iscolumn(tmpngrid))
    tmpngrid = tmpngrid';
end

%
% Create the xgrid as a compact grid in a cell array.
%
xgrid = cell(bss.ndim,1);
h     = zeros(bss.ndim,1);

for idim = 1:bss.ndim
    xgrid{idim} = linspace(bss.bnds(idim,1),bss.bnds(idim,2),tmpngrid(idim))';
    h(idim) = xgrid{idim}(2)-xgrid{idim}(1);
end

%
% For future reference, this temporary variable si probably not needed,
% just put the RHS in the calls below.
%
x = bssgridpoints(xgrid);

%
% Select the right case and compute the values.
%
switch( bss.ndim )
   case 1
      ygrid = bsseval1d(x,bss,evalfun);
   case 2
      ygrid = bsseval2d(x,bss,evalfun);
   case 3
      ygrid = bsseval3d(x,bss,evalfun);
   otherwise
      ygrid = bssevalnd(x,bss,evalfun);
end

if ( bss.ndim > 1)
    ygrid = reshape(ygrid,tmpngrid);
end
