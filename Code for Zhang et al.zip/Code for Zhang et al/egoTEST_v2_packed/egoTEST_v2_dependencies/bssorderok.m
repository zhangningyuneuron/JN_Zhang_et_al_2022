function orderok = bssorderok(m)
% BSSPARTITIONSIZEOK - Check the nominal partition size for a B-spline
% series for validity
%
% INPUTS:
%
%    m:
%       The order of the bsplines to be used. This must be an integer scalar
%       value greater than zero (M>=1).
%
%       This is a scalar.
%
%       M must:
%
%         be nonempty
%         be numeric
%         be >= 1
%         and be a whole number
%
% OUTPUTS:
%
%   orderok:
%      A logical flag indicating whether M passed (1) or failed (0) its
%      validation tests.
%

%
% Copyright 2014-2018 Biometrics Northwest LLC
%

%
% Created: 2014-11-25
% Author : Kevin R. Gehringer
%

%
% Define an initial value that is false.
%
orderok = 0;

%
% Begin the testing with nonempty and numeric.
%
if ( isempty(m) )
   error('The B-spline series order was empty.');
end

if ( ~isnumeric(m) )
   error('The B-spline series order was not numeric.');
end

%
%  Check to see if N is a scalar. 
%
if ( ~isscalar(m) )
   error('The B-spline series order was not a scalar value.');
end

%
% The order must be at least 1.
%
if ( m < 1 )
   error('The B-spline series order must >= 1.');
end

%
% Check to see that M is a whole number by rounding toward zero.
%

if ( (m-fix(m)) ~= 0 )
   error('The order for the B-Spline series (%g) was not an integer value.',m);
end

%
% The validation tests were passed, set output value to true.
%
orderok = 1;
