%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% ################################################################# %% DESCRIPTION
%FUNCTION  short descr.
% long descr.
%
% USAGE:
%         [out] = template(in,in2)
%
% INPUT:
%         in - input 1
%         in2 - input 2
%
% OUTPUT:
%    p - output
%
% EXAMPLES:
%
% See also: FUNCTION2 FUNCTION3

% HISTORY:
% version 1.0.0, Release 00/00/00 Initial release
%
% Author: Roddy Grieves
% UCL, 26 Bedford Way
% eMail: r.grieves@ucl.ac.uk
% Copyright 2019 Roddy Grieves

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% ################################################################# %% INPUT ARGUMENTS CHECK
% deal with initial variables
    figure('visible',fig_vis,'Position',[50,60,1600,900],'Color','w');
    fv = 5;
    fh = nparts+1;
    pidx = reshape(1:(fv*fh),fh,fv);
    p = 1;
    
    fspac = 0.02; % the spacing around the plots, on all sides
    fpadd = 0.01; % the spacing around the plots, on all sides, this takes more space than fspac though
    fmarg = 0.03; % the margins around the plots, at the edge of the figure
    fsiz = 5; % the fontsize for different texts
    flw = 1; % the line width for different plots
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% ################################################################# %% Generate figure    
%% For each part     
    % now we are also going to loop over every part/session so we can analyse the spikes that
    % occured in just one recording session for instance.
    for pp = 1:nparts % for every partition  
        % part_now is a very useful variable, it tells us the name of the current part and can be used to
        % index into part_config where a lot of the data are stored
        part_now = part_names{pp}; % the name of the current part    

        % sort out environment data
        enow = part_config.environment(pp);
%         if enow == 0 % if this should be ignored, skip it
%             continue
%         end     

        %% retrieve position and spike data
        % again we are just getting the data which have already been saved to sdata which saves a lot of time
        % typically, pox and poy are all the position x and y data recorded, whereas ppox and ppoy are the position x and y
        % recorded in this part only, same for spx and pspx
        % I save the data as int16 or single to save space when sdata is saved, so we have to convert to double here so inpolygon etc works
        ppox = double(pdata.(part_now).pox);  
        ppoy = double(pdata.(part_now).poy);  
        ppot = double(pdata.(part_now).pot);              
        ppoh = double(pdata.(part_now).poh);  
        alpha = pdata.(part_now).ego_alpha;
        alpha = double(mod(-alpha+90,360));
        
        pspx = pdata.pox(sdata.spike_index{strcmp(sdata.uci,uci) & strcmp(sdata.part,part_now)});
        pspy = pdata.poy(sdata.spike_index{strcmp(sdata.uci,uci) & strcmp(sdata.part,part_now)});
        psph = pdata.poh(sdata.spike_index{strcmp(sdata.uci,uci) & strcmp(sdata.part,part_now)});        
        pspt = sdata.spike_times{strcmp(sdata.uci,uci) & strcmp(sdata.part,part_now)};
        pspx(pspt<min(ppot) | pspt>max(ppot)) = []; % some spike times are a fraction of a second larger than the max position time, must be an error in Ningyu's version of klustest
        pspy(pspt<min(ppot) | pspt>max(ppot)) = [];
        pspt(pspt<min(ppot) | pspt>max(ppot)) = [];
        sindx = knnsearch(ppot(:),pspt(:));
        pspa = alpha(sindx);        

        if ~numel(pspx) % if there are no spikes             
            continue
        end
        sdindx = strcmp(sdata.uci,uci) & strcmp(sdata.part,part_now);
        
%% Spike and position plot            
        subaxis(fv,fh,pidx(pp,1),'Spacing',fspac,'Padding',fpadd,'Margin',fmarg,'Holdaxis'); hold on;
            plot(ppox,ppoy,'k'); hold on;
            scatter(pspx,pspy,18,pspa,'filled');
            daspect([1 1 1])
            axis xy off tight
            colormap(gca,hsv);
            caxis([0 360]);
            title(sprintf('%d Spikes, %.1f s',numel(pspx),numel(pspx)./(numel(ppox)*(1/50))),'FontSize',fsiz,'FontWeight','normal')

%% Firing rate map                              
        subaxis(fv,fh,pidx(pp,2),'Spacing',fspac,'Padding',fpadd,'Margin',fmarg,'Holdaxis'); hold on;
            rmap2 = sdata.spatial_ratemap{sdindx};
            im = imagesc(rmap2);
            set(im,'alphadata',~isnan(rmap2));
            daspect([1 1 1])
            caxis([0 prctile(rmap2(:),99)]);            
            axis xy off
            title(sprintf('Ratemap, max = %.1f',nanmax(rmap2(:))),'FontSize',fsiz,'FontWeight','normal')                
        
%% Egocentric tuning map                              
        subaxis(fv,fh,pidx(pp,3),'Spacing',fspac,'Padding',fpadd,'Margin',fmarg,'Holdaxis'); hold on;
            angle_bin_edge = pdata.(part_now).angle_bin_edge;
            distance_bin_edge = pdata.(part_now).distance_bin_edge;              
            [theta,rad] = meshgrid(linspace(min(angle_bin_edge),max(angle_bin_edge),length(angle_bin_edge)-1),linspace(min(distance_bin_edge),max(distance_bin_edge),length(distance_bin_edge)-1));
            [Y,X] = pol2cart(deg2rad(theta),rad);  
            ego_rmap = sdata.egocentric_ratemap{sdindx};      
            s = surf(X,Y,ego_rmap);
            s.EdgeColor = 'none';
            view(0,90);
            daspect([1 1 1])
            caxis([0 prctile(ego_rmap(:),99)]);

            % get the cell's egocentric values
            MRL = sdata.mean_resultant_length(sdindx);   
            MRA = sdata.mean_resultant_angle(sdindx);   
            MRAd = sdata.mean_resultant_angle_degrees(sdindx); 
            MRD = sdata.mean_resultant_distance(sdindx);
            dispn = sdata.ego_rmap_dispersion(sdindx);
            cohe = sdata.ego_rmap_coherence(sdindx);       

            ax = gca;
            axis off; hold on;
            ax.FontSize = fsiz;  
            ax.XLim = [-max(rad(:)) max(rad(:))];
            ax.YLim = [-max(rad(:)) max(rad(:))];                
            pad = 1.2;
            text(0,ax.YLim(2).*pad,'Front','HorizontalAlignment','center','FontSize',ax.FontSize)
            text(0,ax.YLim(1).*pad,'Back','HorizontalAlignment','center','FontSize',ax.FontSize)
            text(ax.XLim(1).*pad,0,'Left','HorizontalAlignment','center','FontSize',ax.FontSize)
            text(ax.XLim(2).*pad,0,'Right','HorizontalAlignment','center','FontSize',ax.FontSize)
            line(ax.XLim,[0 0],[100 100],'Color','w','LineStyle',':')
            line([0 0],ax.YLim,[100 100],'Color','w','LineStyle',':')
            ee = ellipse(MRD,MRD,0,0,0,'w');
            set(ee,'LineStyle',':');
            set(ee,'ZData',ones(size(ee.XData)).*100);
            text(ax.XLim(1).*1.35,ax.YLim(2).*0.95,sprintf('%.2f%c\n%.2fcm\n%.1fHz\n%.2f',MRAd,176,MRD,nanmax(ego_rmap(:)),MRL),'HorizontalAlignment','left','FontSize',ax.FontSize)
            text(ax.XLim(1).*1.35,ax.YLim(1).*0.95,sprintf('Disp %.2f\nCohe %.2f',dispn,cohe),'HorizontalAlignment','left','FontSize',ax.FontSize)

%% Egocentric tuning shown as a polar plot with directional line
        s = subaxis(fv,fh,pidx(pp,4),'Spacing',fspac,'Padding',fpadd,'Margin',fmarg); hold on;
        axpos = get(s,'position'); delete(s);
        polaraxes('Position',axpos); 

            x = [histcents(angle_bin_edge)-360;histcents(angle_bin_edge);histcents(angle_bin_edge)+360];
            r = double([sum(ego_rmap,1) sum(ego_rmap,1) sum(ego_rmap,1)]) ./ size(ego_rmap,1);
            nx = 0:1:360;
            MRplot = interp1(x(:),r(:),nx(:),'linear');

            polarplot(deg2rad(nx),MRplot,'k'); hold on;
            ax = gca;
            ax.FontSize = 6;
            ax.ThetaDir = 'clockwise';
            ax.ThetaZeroLocation = 'top';    
            ax.ThetaTick = [0 90 180 270];
            ax.RTick = [];
            ax.RLim = [0 max(MRplot(:))];
            ax.GridColor = 'k';
            ax.GridAlpha = 1;
            ax.ThetaAxis.Visible = 'off';
            ax.FontSize = fsiz;
            r = max(MRplot(:))*1.2; 
            text(0,-r,'Back','HorizontalAlignment','center','FontSize',ax.FontSize);
            text(pi/2,-r,'Left','HorizontalAlignment','center','FontSize',ax.FontSize);
            text(pi,-r,'Front','HorizontalAlignment','center','FontSize',ax.FontSize);
            text(pi.*1.5,-r,'Right','HorizontalAlignment','center','FontSize',ax.FontSize);

            rs = 0:0.1:r;
            polarplot(ones(size(rs)).*MRA,rs,'r','LineWidth',1.5); hold on;
            text(deg2rad(310),r.*1.5,sprintf('%.1fHz',r),'HorizontalAlignment','left','FontSize',ax.FontSize)

%% HD plot for the whole session                                
        s = subaxis(fv,fh,pidx(pp,5),'Spacing',fspac,'Padding',fpadd+0.002,'Margin',fmarg); hold on;
            %% retrieve HD analyses    
            % these are the data that were made inside that awkward cell array loop
            % it is fine here though, because I know the names that were stored in nindx (like 'whole') I can
            % just reference straight into the structure and get the data back (like 'sdata.(uci).(part_now).whole_hd')
            hdata = sdata.compartment_hd_maps{strcmp(sdata.uci,uci) & strcmp(sdata.part,part_now)};
            ai = linspace(0,2*pi,pdata.conset.hd_bins)'; % angles for binning, I take n bins between 0 and 2pi where n = conset.hd_bins
            ai = ai(:); % you will see me do this a lot, it is just to make sure the variable is a vertical column vector rather than a horizontal one

            hd1 = hdata(1,:,1); % this is the session HD (occupancy)
            hd2 = hdata(2,:,1); % this is the cell HD
            hd3 = hdata(3,:,1); % this is the cell's firing rate (hd1 / hd2)
            rv = sdata.compartment_hd_rayleigh(strcmp(sdata.uci,uci) & strcmp(sdata.part,part_now),1);
            mx2 = sdata.compartment_hd_max(strcmp(sdata.uci,uci) & strcmp(sdata.part,part_now),1); % the angle of the peak firing rate in radians I think
            mn2 = sdata.compartment_hd_mean(strcmp(sdata.uci,uci) & strcmp(sdata.part,part_now),1); % the circular mean firing rate angle
            sd2 = sdata.compartment_hd_sd(strcmp(sdata.uci,uci) & strcmp(sdata.part,part_now),1); % the circular standard deviation of this mean

            %% polar plot
            % mmpolar is a function that basically all of the HD people use, in case you haven't seen it before
            % it has a bunch of options and extra inputs that allow very specific modifications
            mmp = mmpolar(ai,hd1,'k',ai,hd3,'b','FontSize',fsiz,'Grid','on','RGridVisible','off','RTickVisible','off','TTickDelta',20,'RTickLabelVisible','on','TTickLabelVisible','on');
            set(mmp(1),'LineWidth',0.5);
            set(mmp(2),'LineWidth',0.5);

            % I like to just add a coloured region to make the HD 'balloon' stand out more, so I add a patch for the session occupancy which is grey
            % - actually transparent black, and another one for the cell's firing which is blue.
            p1 = patch(get(mmp(1),'XData'),get(mmp(1),'YData'),'k','FaceAlpha',0.2);
            p2 = patch(get(mmp(2),'XData'),get(mmp(2),'YData'),'b','FaceAlpha',0.5);
            title(sprintf('r: %.2f, %c: %.2f, %c: %.2f, %s: %.2f',rv,char(708),mx2,char(956),mn2,char(963),sd2),'FontSize',fsiz,'FontWeight','normal');
            ylabel(sprintf('%d spikes (%.1fHz)',numel(psph),numel(psph)/(numel(ppoh)*(1/50))),'FontSize',fsiz)             

    end    
    
%% ##################################### Add data for combined session     
%% Egocentric tuning map                              
    subaxis(fv,fh,pidx(nparts+1,1),'Spacing',fspac,'Padding',fpadd,'Margin',fmarg,'Holdaxis'); hold on;
        sdindx = find(strcmp(sdata.uci,uci),1,'first');
        combined_rmap = sdata.combined_egocentric_ratemap{sdindx};
        combined_rmap_half1 = sdata.combined_egocentric_ratemap_half1{sdindx};
        combined_rmap_half2 = sdata.combined_egocentric_ratemap_half2{sdindx};
        MRL_dat = sdata.combined_egocentric_metrics{sdindx};
        MRL_dat_shuff = sdata.combined_shuffle_egocentric_metrics{sdindx};    

        s = surf(X,Y,combined_rmap);
        s.EdgeColor = 'none';
        view(0,90);
        daspect([1 1 1])
        caxis([0 prctile(combined_rmap(:),99)]);

        % get the cell's egocentric values
        MRL = MRL_dat(1,1);   
        MRA = MRL_dat(1,2);
        MRAd = MRL_dat(1,3);
        MRD = MRL_dat(1,4);  

        ax = gca;
        axis off; hold on;
        ax.FontSize = fsiz;  
        ax.XLim = [-max(rad(:)) max(rad(:))];
        ax.YLim = [-max(rad(:)) max(rad(:))];                
        pad = 1.2;
        text(0,ax.YLim(2).*pad,'Front','HorizontalAlignment','center','FontSize',ax.FontSize)
        text(0,ax.YLim(1).*pad,'Back','HorizontalAlignment','center','FontSize',ax.FontSize)
        text(ax.XLim(1).*pad,0,'Left','HorizontalAlignment','center','FontSize',ax.FontSize)
        text(ax.XLim(2).*pad,0,'Right','HorizontalAlignment','center','FontSize',ax.FontSize)
        line(ax.XLim,[0 0],[100 100],'Color','w','LineStyle',':')
        line([0 0],ax.YLim,[100 100],'Color','w','LineStyle',':')
        ee = ellipse(MRD,MRD,0,0,0,'w');
        set(ee,'LineStyle',':');
        set(ee,'ZData',ones(size(ee.XData)).*100);
        text(ax.XLim(1).*1.35,ax.YLim(2).*0.95,sprintf('%.2f%c\n%.2fcm\n%.1fHz\n%.2f',MRAd,176,MRD,nanmax(combined_rmap(:)),MRL),'HorizontalAlignment','left','FontSize',ax.FontSize)

%% Egocentric tuning shown as a polar plot with directional line
    s = subaxis(fv,fh,pidx(nparts+1,2),'Spacing',fspac,'Padding',fpadd,'Margin',fmarg); hold on;
    axpos = get(s,'position'); delete(s);
    polaraxes('Position',axpos); 

        x = [histcents(angle_bin_edge)-360;histcents(angle_bin_edge);histcents(angle_bin_edge)+360];
        r = double([sum(combined_rmap,1) sum(combined_rmap,1) sum(combined_rmap,1)]) ./ size(combined_rmap,1);
        nx = 0:1:360;
        MRplot = interp1(x(:),r(:),nx(:),'linear');

        polarplot(deg2rad(nx),MRplot,'k'); hold on;
        ax = gca;
        ax.FontSize = 6;
        ax.ThetaDir = 'clockwise';
        ax.ThetaZeroLocation = 'top';    
        ax.ThetaTick = [0 90 180 270];
        ax.RTick = [];
        ax.RLim = [0 max(MRplot(:))];
        ax.GridColor = 'k';
        ax.GridAlpha = 1;
        ax.ThetaAxis.Visible = 'off';
        ax.FontSize = fsiz;
        r = max(MRplot(:))*1.2; 
        text(0,-r,'Back','HorizontalAlignment','center','FontSize',ax.FontSize);
        text(pi/2,-r,'Left','HorizontalAlignment','center','FontSize',ax.FontSize);
        text(pi,-r,'Front','HorizontalAlignment','center','FontSize',ax.FontSize);
        text(pi.*1.5,-r,'Right','HorizontalAlignment','center','FontSize',ax.FontSize);

        rs = 0:0.1:r;
        polarplot(ones(size(rs)).*MRA,rs,'r','LineWidth',1.5); hold on;
        text(deg2rad(310),r.*1.5,sprintf('%.1fHz',r),'HorizontalAlignment','left','FontSize',ax.FontSize)

%% Chance distribution for whole session
    s = subaxis(fv,fh,pidx(nparts+1,3),'Spacing',fspac,'Padding',fpadd,'Margin',fmarg); hold on;
        obs = MRL_dat(1,1);
        shuff = MRL_dat_shuff(:,1,1);
        prc = prctile(shuff(:),95);
        
        bs = .005;
        xi = (min([reshape(MRL_dat_shuff(:,1,:),[],1,1);MRL_dat(:,1)])-bs*3):bs:(max([reshape(MRL_dat_shuff(:,1,:),[],1,1);MRL_dat(:,1)])+bs*3);
        bw = bs;
        f = ksdensity(shuff(:),xi,'kernel','epanechnikov','bandwidth',bw).*bs;
        
        area(xi,f,'FaceColor','k','FaceAlpha',0.2); hold on;
        ax = gca;
        ax.XLim = [min(xi) max(xi)];
        line([obs obs],ax.YLim,'Color','b','LineWidth',1);
        line([prc prc],ax.YLim,'Color','r','LineWidth',1); 
        xlabel('MRL')
        ylabel('Cells')
        set(gca,'yticklabel',num2str(get(gca,'ytick')','%.2f')) % change Ytick labels to have the same number of decimal places

%% Chance distribution for first half
    s = subaxis(fv,fh,pidx(nparts+1,4),'Spacing',fspac,'Padding',fpadd,'Margin',fmarg); hold on;
        obs = MRL_dat(2,1);
        shuff = MRL_dat_shuff(:,1,2);
        prc = prctile(shuff(:),95);
        
        bs = .005;
        bw = bs;
        f = ksdensity(shuff(:),xi,'kernel','epanechnikov','bandwidth',bw).*bs;
        
        area(xi,f,'FaceColor','k','FaceAlpha',0.2); hold on;
        ax = gca;
        ax.XLim = [min(xi) max(xi)];        
        line([obs obs],ax.YLim,'Color','b','LineWidth',1);
        line([prc prc],ax.YLim,'Color','r','LineWidth',1);
        xlabel('MRL')
        ylabel('Cells')
        set(gca,'yticklabel',num2str(get(gca,'ytick')','%.2f')) % change Ytick labels to have the same number of decimal places
        
%% Chance distribution for second half
    s = subaxis(fv,fh,pidx(nparts+1,5),'Spacing',fspac,'Padding',fpadd,'Margin',fmarg); hold on;
        obs = MRL_dat(3,1);
        shuff = MRL_dat_shuff(:,1,3);
        prc = prctile(shuff(:),95);
        
        bs = .005;
        bw = bs;
        f = ksdensity(shuff(:),xi,'kernel','epanechnikov','bandwidth',bw).*bs;
        
        area(xi,f,'FaceColor','k','FaceAlpha',0.2); hold on;
        ax = gca;
        ax.XLim = [min(xi) max(xi)];
        line([obs obs],ax.YLim,'Color','b','LineWidth',1);
        line([prc prc],ax.YLim,'Color','r','LineWidth',1);
        xlabel('MRL')
        ylabel('Cells')    
        set(gca,'yticklabel',num2str(get(gca,'ytick')','%.2f')) % change Ytick labels to have the same number of decimal places
            
        
%         set(gcf,'visible','on')
%         keyboard
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Save the figure    
    figfile = [pwd '\klustest\' pdata.combined_name '\figures\'];
    [~,~,~] = mkdir(figfile);
    print(gcf,'-dpng','-r150',[figfile uci '_egotest1.png'])
    close(gcf);                                          





    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    