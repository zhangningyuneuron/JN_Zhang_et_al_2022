function y = bssevalnd(x, bss, evalfun)
%BSSEVAL  Evaluate the N-dimensional B-Spline series at x.
%
% INPUTS:
%
%    x:
%       The data to be used for evaluating the B-Spline series. This is an 
%       NPOINTS by NDIM matrix with the rows representing the points.
%
%       X must be a matrix with NDIM  >= 1.
%
%    bss:
%       The B-Spline series data structure containing the series to be used
%       for evaluation.
%
%
%    evalfun:
%       The function that is to be evaluated. If the B-Spline series
%       represents a probability density function, the following output
%       functions are available 'pdf' (the default), 'cdf', and 'survivor'.
%       If no evaluation function is specified the B-Spline series is
%       simply evaluated without transformations.
%
%       Allowed evaluation functions if the B-Spline series represents a
%       probability density function:
%
%          pdf      : The probability density function, f(x) (default)
%          cdf      : The cumulative distribution function, F(x)
%          survivor : The survivor function, S(x) = 1-F(x)
%
% OUTPUTS:
%
%    y:
%       The values for the B-Spline series evaluated at x.
%
%       If the B-Spline series represents a probability density function
%       and one of the allowed functions is specified, then the output is
%       an approximation of the desired function based on the probability
%       density function represented by the B-Spline series.
%

%
% Copyright 2014-2018 Biometrics Northwest LLC
%

%
% Modified: 2018-08-17
% Author : Kevin R. Gehringer
%
%    Fixed an off by one error when generating linear index values.
%    bss.partition.npart was used and it should have been
%    bss.partition.npart-1.
%
% Modified: 2016-10-10
% Author : Kevin R. Gehringer
%
%    If the number of inbounds points was zero an error occurred, but the
%    output values should all have had a value of zero. This was fixed. If
%    all points are out of bounds zero values are returned.
%
% Modified: 2016-03-12
% Author : Kevin R. Gehringer
%
%   Several enhancements were made to improve the performance:
%
%   1) Replaced outer products with vectors of ones used to replicate data
%      with calls to REPMAT. Since REPMAT is now a built-in function it is
%      significantly faster than using the outer product to do replication.
%   2) Removed unnecessary reshaping for B-splines of order 1.
%   3) Changed the matrix orientation from m by n to n by m, where m is the
%      B-spline order and n is the total number of evaluation points
%      specified by the input X.
%   4) Removed unnecessary temporary variables.
%   5) Removed an unnecessary transpose of the partition sizes.
%
% Created: 2014-11-25
% Author : Kevin R. Gehringer
%

%
% We gotta have the data array X.
%
% Check data for validity. The data must:
%   exist
%   be nonempty
%   be numeric
%   be an NDATA by NDIM matrix, where NDIM >= 1 and NDATA is the
%   number of rows
%
if ( ~exist('x','var') )
   error('The evaluation points array was not supplied.');
end

if ( isempty(x) )
   error('The evaluation points array was empty.');
end

if ( ~isnumeric(x) )
   error('The evaluation points array was not numeric.');
end

%
% At this point, we know that X exists, is nonempty, and numeric.
%
% Get the number of dimensions and check. Only values
% of 1, 2, or 3 are valid.
%
sz_x = size(x);

if ( length(sz_x) ~= 2 )
   error('The data array must be 2-dimensional with rows representing the data points.');
end
   
ndim_x = sz_x(2);
if ( ndim_x < 1 )
   error('The number of dimensions used for the data array must be at least 1 and a value of %d was found.',ndim_x);
end

%
% We gotta have a b-spline series structure.
%
if ( ~exist('bss','var') )
   error('The B-spline series data structure was not provided.');
end

if ( isempty(bss) )
   error('The B-spline series data structure was empty.');
end

if ( bss.ndim < 1 )
   error('The number of dimensions must be at least 1 and a value of %d was found in the B-spline series structure.',bss.ndim);
end

%
%   Check to see if an evaluation function was specified. If not, assign
%   the default.
%
    if ( ~exist('evalfun','var') )
        evalfun = 'bss';
    end
%
%   Validate the evaluation function and zero tolerance based on the domain
%   dimension. Valid values are: 'bss', 'pdf', 'cdf', 'survivor'.
%
    okfuns = {'bss';'pdf';'cdf';'survivor'};
    if ( ~any(strcmpi(evalfun,okfuns)) )
        error('The evaluation function ''%s'' was not recognized.',evalfun);
    end
%
%   Call the appropriate function.
%
    switch (lower(evalfun))
        case {'bss'}
            y = do_bss(x,bss);
        case {'pdf'}
            y = do_pdf(x,bss);
        case {'cdf'}
            y = do_cdf(x,bss);
        case {'survivor'}
            y = do_survivor(x,bss);
        otherwise
            error('The function ''%s'' was not recognized.',evalfun);
    end
    
end

function y = do_bss(x,bss)

    mp1to0 = (-bss.m+1:0)';
    
    npts_x  = size(x,1);
    y = zeros(npts_x,1);

    inbounds = true(npts_x,1);
    for idim = 1:bss.ndim
       inbounds = inbounds & ((x(:,idim) >= bss.bnds(idim,1)) & (x(:,idim) < bss.bnds(idim,2)));
    end
    inbounds = find(inbounds);
    n  = length(inbounds);

    if ( n == 0 )
        return;
    end

    do_interp = isfield(bss,'bss') && ~isempty(bss.bss);
    
    if ( ~do_interp )
 
        xtmp = (x(inbounds,:) - repmat(bss.bnds(:,1)',n,1))*diag(1./bss.partition.h);
        xidx = bss.m + floor(xtmp);

        for idim = 1:bss.ndim
            xidx(xidx(:,idim) < bss.m,idim) = bss.m;
            xidx(xidx(:,idim) > bss.partition.npart(idim)-1,idim) = bss.partition.npart(idim) - 1;
        end

        idxp = zeros(bss.m,bss.ndim);
        xpn = zeros(bss.m,bss.ndim);

        for idata = 1:n

           for idim = 1:bss.ndim
              idxp(:,idim) = xidx(idata,idim) + mp1to0;
              xpn(:,idim)  = (bss.partition.x(idxp(:,idim),idim)-bss.bnds(idim,1))./bss.partition.h(idim);
           end

           xdiff = repmat(xtmp(idata,:),bss.m,1) - xpn;
           fbtmp = bssfbspline(xdiff(:),bss.m);
           fbtmp = reshape(fbtmp,bss.m,bss.ndim);
   
           tp   = bsstensorproduct(fbtmp);
           tpi  = bsstensorindex(idxp);
           tpli = bsssub2ind(bss.partition.npart-1,tpi);
   
           ytmp  = bss.c(tpli) .* tp;

           y(inbounds(idata)) = sum(ytmp);
   
        end

    else
        f = griddedInterpolant(bss.bss.xgrid,bss.bss.ygrid,'linear');
        y(inbounds) = f(x(inbounds,:));
    end

end

function y = do_pdf(x,bss)

    do_interp = isfield(bss,'pdf') && ~isempty(bss.pdf);
    
    if ( ~do_interp )
        y = do_bss(x,bss);
    else
        f = griddedInterpolant(bss.pdf.xgrid,bss.pdf.ygrid,'linear');
        y = f(x);
        y(y<0) = 0;
    end
end

function y = do_cdf(x,bss)

    npts_x = size(x,1);
    
    inbounds = true(npts_x,1);
    for idim = 1:bss.ndim
       inbounds = inbounds & ((x(:,idim) >= bss.bnds(idim,1)) & (x(:,idim) < bss.bnds(idim,2)));
    end
    
    if (bss.ndim<=3)
        y = zeros(npts_x,1);
    else
        y = nan(npts_x,1);
    end

    do_interp = isfield(bss,'cdf') && ~isempty(bss.cdf);
    
    if ( ~do_interp )
        
        xcdf = cell(bss.ndim,1);
        ndim = zeros(1,bss.ndim);
        h     = zeros(bss.ndim,1);
        np = floor(bsspointsperpartition(bss.ndim)*bss.partition.n)+1;
        for idim = 1:bss.ndim
            xcdf{idim} = linspace(bss.bnds(idim,1),bss.bnds(idim,2),np(idim))';
            ndim(idim) = length(xcdf{idim});
            h(idim) = xcdf{idim}(2)-xcdf{idim}(1);
        end

        ycdf = do_pdf(bssgridpoints(xcdf),bss);
        if (bss.ndim>1)
            ycdf = reshape(ycdf,ndim);
        end
        if (bss.ndim == 1)
            ycdf = cumtrapz(xcdf{1},ycdf);
        else
            for idim = 1:bss.ndim
                ycdf = cumsum(ycdf,idim);
            end
            ycdf = prod(h)*ycdf;
        end
%
%   fix any roundoff errors that may have made the CDF greater than one.
%
        ycdf(ycdf>1) = 1;

        if (bss.ndim<=3)
            cdf = griddedInterpolant(xcdf,ycdf,'linear');
        else
            cdf = griddedInterpolant(xcdf,ycdf,'linear','none');
        end
    
        y(inbounds) = cdf(x(inbounds,:));
    
    else
        cdf = griddedInterpolant(bss.cdf.xgrid,bss.cdf.ygrid,'linear');
        y(inbounds) = cdf(x(inbounds,:));
    end
%   fix values for out of bounds points that may make sense for dimensions
%   1, 2, or 3. This basically performs extrapolations of the edge values
%   at the boundary of the B-Spline series estimation domain.
%
    switch(bss.ndim)
        
        case 1
            
%           y(x < bss.bnds(1)) = 0;
            y(x >= bss.bnds(2)) = 1;
            
        case 2
            
%           y((x(:,1) < bss.bnds(1,1)) | (x(:,2) < bss.bnds(2,1))) = 0;
            y((x(:,1) >= bss.bnds(1,2)) & (x(:,2) >= bss.bnds(2,2))) = 1;
        
            idx1gt2 = find((x(:,1) >= bss.bnds(1,2)) & (x(:,2) < bss.bnds(2,2)));
            if ( ~isempty(idx1gt2) )
                y(idx1gt2) = cdf([bss.bnds(1,2)*ones(length(idx1gt2),1) x(idx1gt2,2)]);
            end
    
            idx2gt1 = find((x(:,1) < bss.bnds(1,2)) & (x(:,2) >= bss.bnds(2,2)));
            if ( ~isempty(idx2gt1) )
                y(idx2gt1) = cdf([x(idx2gt1,1) bss.bnds(2,2)*ones(length(idx2gt1),1)]);
            end
            
        case 3
            
%           y((x(:,1) < bss.bnds(1,1)) | (x(:,2) < bss.bnds(2,1))) = 0;
            y((x(:,1) >= bss.bnds(1,2)) & (x(:,2) >= bss.bnds(2,2)) & (x(:,3) >= bss.bnds(3,2))) = 1;
    
            idx1gt23lt = find((x(:,1) >= bss.bnds(1,2)) & (x(:,2) < bss.bnds(2,2)) & (x(:,3) < bss.bnds(3,2)));
            if ( ~isempty(idx1gt23lt) )
                y(idx1gt23lt) = cdf([bss.bnds(1,2)*ones(length(idx1gt23lt),1) x(idx1gt23lt,2) x(idx1gt23lt,3)]);
            end
    
            idx2gt13lt = find((x(:,1) < bss.bnds(1,2)) & (x(:,2) >= bss.bnds(2,2)) & (x(:,3) < bss.bnds(3,2)));
            if ( ~isempty(idx2gt13lt) )
                y(idx2gt13lt) = cdf([x(idx2gt13lt,1) bss.bnds(2,2)*ones(length(idx2gt13lt),1) x(idx2gt13lt,3)]);
            end

            idx3gt12lt = find((x(:,1) < bss.bnds(1,2)) & (x(:,2) < bss.bnds(2,2)) & (x(:,3) >= bss.bnds(3,2)));
            if ( ~isempty(idx3gt12lt) )
                y(idx3gt12lt) = cdf([x(idx3gt12lt,1) x(idx3gt12lt,2) bss.bnds(3,2)*ones(length(idx3gt12lt),1)]);
            end

            idx12gt3lt = find((x(:,1) >= bss.bnds(1,2)) & (x(:,2) >= bss.bnds(2,2)) & (x(:,3) < bss.bnds(3,2)));
            if ( ~isempty(idx12gt3lt) )
                y(idx12gt3lt) = cdf([bss.bnds(1,2)*ones(length(idx12gt3lt),1) bss.bnds(2,2)*ones(length(idx12gt3lt),1) x(idx12gt3lt,3)]);
            end

            idx13gt2lt = find((x(:,1) >= bss.bnds(1,2)) & (x(:,2) < bss.bnds(2,2)) & (x(:,3) >= bss.bnds(3,2)));
            if ( ~isempty(idx12gt3lt) )
                y(idx13gt2lt) = cdf([bss.bnds(1,2)*ones(length(idx13gt2lt),1) x(idx13gt2lt,2) bss.bnds(3,2)*ones(length(idx13gt2lt),1)]);
            end

            idx23gt1lt = find((x(:,1) < bss.bnds(1,2)) & (x(:,2) >= bss.bnds(2,2)) & (x(:,3) >= bss.bnds(3,2)));
            if ( ~isempty(idx23gt1lt) )
                y(idx23gt1lt) = cdf([x(idx23gt1lt,1) bss.bnds(2,2)*ones(length(idx23gt1lt),1) bss.bnds(3,2)*ones(length(idx23gt1lt),1)]);
            end
    
    end
    
    y(y<0) = 0;
    y(y>1) = 1;

end

function y = do_survivor(x,bss)

    y = 1 - do_cdf(x,bss);
    
end
