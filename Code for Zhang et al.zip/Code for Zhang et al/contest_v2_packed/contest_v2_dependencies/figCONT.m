function figCONT(pdata,sdata,uci,fig_vis)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   This function takes an sdata structure, a cell identifier and generates a figure for the context box experiment
%   figCONT(sdata,uci,fig_vis,save_fig)
%
%%%%%%%% Inputs
%   sdata = sdata structure from context box function
%   uci = unique cell identifier
%   fig_vis = (optional), 'on' to show figures, 'off' to hide figures, default is 'off'
%   save_fig = (optional), 1 to save figures in .fig files, 0 otherwise, default is 0
%
%%%%%%%% Comments
%   04/07/17 created to contain all of this figure code
%   25/07/17 fixed scaling problem from variable pixel ratio
%   � Roddy Grieves: rmgrieves@gmail.com
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Initial variables
    if ~exist('fig_vis','var') || isempty(fig_vis)
        fig_vis = 'off';
    end

    part_names = table2cell(pdata.part_config(:,2))'; % the names you want the outputs to be saved as, these cannot start with a number: i.e. 'session1'
    nparts = length(part_names);
    part_config = pdata.part_config;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Create figure
    figpoly = figure('visible',fig_vis,'Position',[100 100 1600 900]); 
    set(gcf,'InvertHardCopy','off'); % this stops white lines being plotted black      
    set(gcf,'color','w'); % makes the background colour white
    colormap(jet(256)); % to make sure the colormap is not the horrible default one
    fig_hor = nparts; % how many plots wide should it be
    fig_ver = 6; % how many plots tall should it be
    fspac = 0.01; % the spacing around the plots, on all sides
    fpadd = 0.01; % the spacing around the plots, on all sides, this takes more space than fspac though
    fmarg = 0.03; % the margins around the plots, at the edge of the figure
    fsiz = 5; % the fontsize for different texts
    flw = 1; % the line width for different plots
    % add an annotation to the figure with some important info    
    ann_str = sprintf('Cell: %s, Analysed: %s',uci,datestr(now,'yyyy-mm-dd-HH-MM-SS'));
    annotation('textbox',[0, 1, 1, 0],'string',ann_str,'FontSize',fsiz,'LineStyle','none','interpreter','none');  
    annotation('textbox',[0.5, 0.98, 1, 0],'string','Position and spikes','FontSize',10,'LineStyle','none','interpreter','none');  
    annotation('textbox',[0.5, 0.74, 1, 0],'string','Whole environment','FontSize',10,'LineStyle','none','interpreter','none');  
    annotation('textbox',[0.5, 0.5, 1, 0],'string','Lemon compartment','FontSize',10,'LineStyle','none','interpreter','none');  
    annotation('textbox',[0.5, 0.25, 1, 0],'string','Vanilla compartment','FontSize',10,'LineStyle','none','interpreter','none');  

% process data and generate figure
    for pp = 1:nparts
%% sort out environment data
        % I reuse a lot of the naming conventions from the parent code, this is to try and make it as understandable as possible
        % For instance enow and rnow etc are the same as before
        part_now = part_names{pp};

        % sort out environment data
%         enow = part_config.environment(pp);
%         if enow == 0 % if this should be ignored, skip it
%             continue
%         end  

%% retrieve position and spike data
        % an exception may be that usually I use pox to mean all position data and use ppox for a part's position data
        % however, here I have used pox instead because its name is shorter and easier to use, so what? its my code, I can do what I want!
        % retrieve position and spike data
        pox = double(pdata.(part_now).pox);
        poy = double(pdata.(part_now).poy);
        poh = double(pdata.(part_now).poh);        
        poc = pdata.(part_now).poc;      
        spx = pdata.pox(sdata.spike_index{strcmp(sdata.uci,uci) & strcmp(sdata.part,part_now)});
        spy = pdata.poy(sdata.spike_index{strcmp(sdata.uci,uci) & strcmp(sdata.part,part_now)});
        sph = pdata.poh(sdata.spike_index{strcmp(sdata.uci,uci) & strcmp(sdata.part,part_now)}); 
        spc = sdata.compartment_index{strcmp(sdata.uci,uci) & strcmp(sdata.part,part_now)};
        
%% load environment polygons
        % remember that epoly is the entire environment, lpoly is the lemon compartment, vpoly is the vanilla compartment   
        epoly = pdata.(part_now).epoly;
        comp_poly = pdata.(part_now).comp_poly;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% plot showing position data and spikes
        % I use this helper function called 'subaxis' because it lets you squeeze plots closer together than normal
        % but it is basically exactly the same as Matlab's inbuilt 'subplot' function
        subaxis(fig_ver,fig_hor,pp,'Spacing',fspac,'Padding',fpadd,'Margin',fmarg,'Holdaxis'); hold on;
    
            % here I use the compartment indices poc and spc to directly index into the spike and position data
            % and extract each compartment's data. This is why making these indices this way is quite helpful
            plot(pox(poc(:,1)),poy(poc(:,1)),'k') % plot all position data inside the environment
            cols = lines(length(comp_poly));
            for ii = 1:length(comp_poly)
                cpoly = comp_poly{ii};
                plot(spx(spc(:,ii)),spy(spc(:,ii)),'Color',cols(ii,:),'MarkerSize',15,'Marker','.','LineStyle','none')
                plot(cpoly(:,1),cpoly(:,2),'Color',cols(ii,:),'Marker','.','LineStyle','none') % plot the lemon compartment
            end
            daspect([1 1 1]) % this makes the axis resolution the same for both x and y, which is the case for coordinates
            axis off
            axis xy
            axis([min(epoly(:,1))-2 max(epoly(:,1))+2 min(epoly(:,2))-2 max(epoly(:,2))+2])
            ename = pdata.part_config.enames{pp};
            rnow = pdata.part_config.rotation(pp);        
            title(sprintf('%s - %d - %d spikes',ename,rnow,sum(spc>0)),'FontSize',fsiz)
        
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% plot showing polar plot for all data (inside the environment)
        subaxis(fig_ver,fig_hor,pp+(nparts),'Spacing',fspac,'Padding',fpadd,'Margin',fmarg,'Holdaxis'); hold on;

            %% retrieve HD analyses    
            % these are the data that were made inside that awkward cell array loop
            % it is fine here though, because I know the names that were stored in nindx (like 'whole') I can
            % just reference straight into the structure and get the data back (like 'sdata.(uci).(part_now).whole_hd')
            hdata = sdata.compartment_hd_maps{strcmp(sdata.uci,uci) & strcmp(sdata.part,part_now)};
            ai = linspace(0,2*pi,pdata.conset.hd_bins)'; % angles for binning, I take n bins between 0 and 2pi where n = conset.hd_bins
            ai = ai(:); % you will see me do this a lot, it is just to make sure the variable is a vertical column vector rather than a horizontal one

            hd1 = hdata(1,:,1); % this is the session HD (occupancy)
            hd2 = hdata(2,:,1); % this is the cell HD
            hd3 = hdata(3,:,1); % this is the cell's firing rate (hd1 / hd2)
            rv = sdata.compartment_hd_rayleigh(strcmp(sdata.uci,uci) & strcmp(sdata.part,part_now),1);
            mx2 = sdata.compartment_hd_max(strcmp(sdata.uci,uci) & strcmp(sdata.part,part_now),1); % the angle of the peak firing rate in radians I think
            mn2 = sdata.compartment_hd_mean(strcmp(sdata.uci,uci) & strcmp(sdata.part,part_now),1); % the circular mean firing rate angle
            sd2 = sdata.compartment_hd_sd(strcmp(sdata.uci,uci) & strcmp(sdata.part,part_now),1); % the circular standard deviation of this mean

            %% polar plot
            % mmpolar is a function that basically all of the HD people use, in case you haven't seen it before
            % it has a bunch of options and extra inputs that allow very specific modifications
            mmp = mmpolar(ai,hd1,'k',ai,hd3,'b','FontSize',fsiz,'Grid','on','RGridVisible','off','RTickVisible','off','TTickDelta',20,'RTickLabelVisible','on','TTickLabelVisible','on');
            set(mmp(1),'LineWidth',0.5);
            set(mmp(2),'LineWidth',0.5);

            % I like to just add a coloured region to make the HD 'balloon' stand out more, so I add a patch for the session occupancy which is grey
            % - actually transparent black, and another one for the cell's firing which is blue.
            p1 = patch(get(mmp(1),'XData'),get(mmp(1),'YData'),'k','FaceAlpha',0.2);
            p2 = patch(get(mmp(2),'XData'),get(mmp(2),'YData'),'b','FaceAlpha',0.5);
            title(sprintf('r: %.2f, %c: %.2f, %c: %.2f, %s: %.2f',rv,char(708),mx2,char(956),mn2,char(963),sd2),'FontSize',6);
            ylabel(sprintf('%d spikes (%.1fHz)',numel(sph),numel(sph)/(numel(poh)*(1/50))),'FontSize',fsiz)             

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% plots showing polar plots for each compartment
        if length(comp_poly)>1
            % these next two sections are basically copy and paste 
            for ii = 2:length(comp_poly) % for every sub compartment
                subaxis(fig_ver,fig_hor,pp+(nparts*ii),'Spacing',fspac,'Padding',fpadd,'Margin',fmarg,'Holdaxis'); hold on;    
                    % retrieve data        
                    hd1 = hdata(1,:,ii); % this is the session HD (occupancy)
                    hd2 = hdata(2,:,ii); % this is the cell HD
                    hd3 = hdata(3,:,ii); % this is the cell's firing rate (hd1 / hd2)
                    rv = sdata.compartment_hd_rayleigh(strcmp(sdata.uci,uci) & strcmp(sdata.part,part_now),2);
                    mx2 = sdata.compartment_hd_max(strcmp(sdata.uci,uci) & strcmp(sdata.part,part_now),2); % the angle of the peak firing rate in radians I think
                    mn2 = sdata.compartment_hd_mean(strcmp(sdata.uci,uci) & strcmp(sdata.part,part_now),2); % the circular mean firing rate angle
                    sd2 = sdata.compartment_hd_sd(strcmp(sdata.uci,uci) & strcmp(sdata.part,part_now),2); % the circular standard deviation of this mean

                    % polar plot
                    mmp = mmpolar(ai,hd1,'k',ai,hd3,'b','FontSize',fsiz,'Grid','on','RGridVisible','off','RTickVisible','off','TTickDelta',20,'RTickLabelVisible','on','TTickLabelVisible','on');
                    set(mmp(1),'LineWidth',0.5);
                    set(mmp(2),'LineWidth',0.5);
                    p1 = patch(get(mmp(1),'XData'),get(mmp(1),'YData'),'k','FaceAlpha',0.2);
                    p2 = patch(get(mmp(2),'XData'),get(mmp(2),'YData'),'b','FaceAlpha',0.5);
                    title(sprintf('r: %.2f, %c: %.2f, %c: %.2f, %s: %.2f',rv,char(708),mx2,char(956),mn2,char(963),sd2),'FontSize',6);
                    ylabel(sprintf('%d spikes (%.1fHz)',sum(spc(:,ii)),sum(spc(:,ii))/(sum(poc(:,ii))*(1/50))),'FontSize',fsiz)   
            end
        end   
    end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Save the figure    
    figfile = [pwd '\klustest\' pdata.combined_name '\figures\'];
    [~,~,~] = mkdir(figfile);
    print(figpoly,'-dpng','-r150',[figfile uci '_contest1.png'])
    close(figpoly);                                          





































